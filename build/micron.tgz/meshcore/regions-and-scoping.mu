#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f

`:Regions-and-Scoping
>Regions and Scoping

`!`Fda5Info: Now: step 1, tagging every repeater`f`!

Michigan is rolling out regions in steps, and step 1 is giving every repeater its region names. Until the next step is announced, your messages travel just as they always have.

 • `!Companion users:`! nothing you need to set. Unscoped messages reach everyone. You're welcome to experiment with scoped messages; they only reach as far as repeaters carry their region, so expect gaps while repeaters are still being tagged.
 • `!Repeater operators:`! define your regions with `Fda5region def`f and `Fda5region save`f, and change no other region or scope settings. `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup/regions.mu`anchor=regions-on-hold]`_`f has the details.

Messages not getting through? Clear your scope: `F79d`_`[companions`:/page/meshcore/getting-started.mu`anchor=undo-region-scoping]`_`f, `F79d`_`[repeaters`:/page/meshcore/repeater-setup/regions.mu`anchor=undo-scoping]`_`f. `F79d`_`[The Rollout`:/page/meshcore/regions-and-scoping/the-plan.mu]`_`f has what's next.

<
`!In this section`!

 • `F79d`_`[How Regions Work`:/page/meshcore/regions-and-scoping/how-regions-work.mu]`_`f
 • `F79d`_`[Why Scoping Matters`:/page/meshcore/regions-and-scoping/why.mu]`_`f
 • `F79d`_`[Why the Names Look Like This`:/page/meshcore/regions-and-scoping/why-the-names.mu]`_`f
 • `F79d`_`[Where Michigan Stands`:/page/meshcore/regions-and-scoping/where-we-are.mu]`_`f
 • `F79d`_`[What To Do Now`:/page/meshcore/regions-and-scoping/what-to-do-now.mu]`_`f
 • `F79d`_`[FAQ`:/page/meshcore/regions-and-scoping/faq.mu]`_`f
 • `F79d`_`[The Rollout`:/page/meshcore/regions-and-scoping/the-plan.mu]`_`f
 • `F79d`_`[The Map and Names`:/page/meshcore/regions-and-scoping/the-map.mu]`_`f
 • `F79d`_`[Open Items`:/page/meshcore/regions-and-scoping/open-items.mu]`_`f
 • `F79d`_`[Learn More`:/page/meshcore/regions-and-scoping/learn-more.mu]`_`f
 • `F79d`_`[Change History`:/page/meshcore/regions-and-scoping/change-history.mu]`_`f

<
-
Previous: `F79d`_`[Full Settings Audit`:/page/meshcore/repeater-setup/full-settings-audit.mu]`_`f
Next: `F79d`_`[How Regions Work`:/page/meshcore/regions-and-scoping/how-regions-work.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/
