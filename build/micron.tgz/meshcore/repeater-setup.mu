#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f

`:Repeater-Setup-Guide
>Repeater Setup Guide

So you've decided to run a repeater. Nice. This guide gets a MeshCore repeater online, tagged with the right Michigan regions, tuned, and verified.

 • `!`F79d`_`[Quick Start`:/page/meshcore/repeater-setup/quick-start.mu]`_`f`!: every command a new Michigan repeater needs, in order. Start here.
 • `!`F79d`_`[Step-by-Step Setup`:/page/meshcore/repeater-setup/step-by-step-setup.mu]`_`f`!: the same steps explained one at a time.
 • `!`F79d`_`[Regions`:/page/meshcore/repeater-setup/regions.mu]`_`f`!: which regions to carry and why.
 • `!`F79d`_`[Claim a Unique Public Key Prefix`:/page/meshcore/repeater-setup/claim-a-unique-public-key-prefix.mu]`_`f`!: do this before the repeater goes on the air.
 • `!`F79d`_`[Delay Profiles`:/page/meshcore/repeater-setup/delay-profiles.mu]`_`f`!: pick one that matches the repeater's height.
 • `!`F79d`_`[Settings Reference`:/page/meshcore/repeater-setup/settings-reference.mu]`_`f`!: what each setting does.
 • `!`F79d`_`[Full Settings Audit`:/page/meshcore/repeater-setup/full-settings-audit.mu]`_`f`!: check everything before and after a field install.

<
`!In this section`!

 • `F79d`_`[Before You Start`:/page/meshcore/repeater-setup/before-you-start.mu]`_`f
 • `F79d`_`[Quick Start`:/page/meshcore/repeater-setup/quick-start.mu]`_`f
 • `F79d`_`[Step-by-Step Setup`:/page/meshcore/repeater-setup/step-by-step-setup.mu]`_`f
 • `F79d`_`[Regions`:/page/meshcore/repeater-setup/regions.mu]`_`f
 • `F79d`_`[Claim a Unique Public Key Prefix`:/page/meshcore/repeater-setup/claim-a-unique-public-key-prefix.mu]`_`f
 • `F79d`_`[Delay Profiles`:/page/meshcore/repeater-setup/delay-profiles.mu]`_`f
 • `F79d`_`[Settings Reference`:/page/meshcore/repeater-setup/settings-reference.mu]`_`f
 • `F79d`_`[Full Settings Audit`:/page/meshcore/repeater-setup/full-settings-audit.mu]`_`f

<
-
Previous: `F79d`_`[Applications To Make Your MeshCore More`:/page/meshcore/meshcore-applications.mu]`_`f
Next: `F79d`_`[Before You Start`:/page/meshcore/repeater-setup/before-you-start.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/
