#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup.mu]`_`f

`:claim-a-unique-public-key-prefix
>Claim a Unique Public Key Prefix

Repeaters identify each other by the leading bytes of their public key. The firmware generates that key at random on first boot, and nothing stops it from landing on a prefix a nearby repeater already uses. See `F79d`_`[Public Key Prefix`:/page/meshcore/repeater-setup/settings-reference.mu`anchor=public-key-prefix]`_`f for why the 2-byte prefix matters.

`!`Fda5Warning: Prior to going online`f`!

The public key `*is`* the repeater's identity. Rekeying means everyone who already has this repeater as a contact has to re-add it, and admin sessions tied to the old identity stop working. Check your prefix now: rekeying a repeater that's already carrying traffic disrupts everyone using it.

`:prefix-1-read
>>1. Read Your Current Prefix

`Fda5
`=
get public.key
`=
`f

 • The `!first 2 hex characters`! (1 byte) are what apps and contact lists show. There are only 256 of these, so duplicates turn up quickly in any busy area.
 • The `!first 4 hex characters`! (2 bytes) are what `Fda5path.hash.mode 1`f stamps into routing paths. This is the one that has to be unique. Two repeaters sharing it both answer to the same path entry and both retransmit, which causes routing issues.

`:prefix-2-backup
>>2. Back Up the Key You Already Have

Before changing anything, save the private key. It's the only way to restore this repeater's identity after a flash erase, or to move that identity onto replacement hardware.

`Fda5
`=
get prv.key
`=
`f

`:prefix-3-check
>>3. Check It Against the Repeaters You Can Hear

Collisions only cause problems between repeaters in range of each other, so the check that counts is a local one. Ask your own node what it actually hears:

`Fda5
`=
neighbors
`=
`f

Each line reads `Fda5<8 hex chars>:<seconds since heard>:<SNR>`f, so `Fda5a1b2c530:143:8`f is a neighbor whose key starts `Fda5a1b2c530`f, heard 143 seconds ago. That last number is SNR times four, so halve it twice; `Fda58`f means 2 dB. Compare the `!first four characters`! of each line against your own, and run this from your repeater once it's on the air.

You'll see roughly the eight most recently heard, even though the repeater tracks more than that. If `Fda5neighbors`f replies `Fda5-none-`f, either nothing has been heard yet or the neighbour table isn't compiled into that variant.

Your companion app's contact list is worth checking too. It collects every repeater it has heard an advert from, which usually reaches further than a single node's neighbour table. MeshMapper (https://meshmapper.net/) is another way to see what's already on the air in your region. However you go about it, the goal is the same: no collision with the repeaters near you.

`:prefix-4-generate
>>4. Generate and Apply a Replacement Key

There is no on-device key generation command, so this step happens in the browser. Open the MeshCore config tool (https://config.meshcore.io/) in a Chromium-based browser and connect to the repeater.

Click `!Edit`! (the pencil icon) next to Public Key, enter the four-character prefix you claimed, click `!Generate`!, then `!Use This Key`! once it finishes.

`!`Fda5Tip: Set your own prefix`f`!

Avoiding collisions is the requirement; picking a prefix you actually recognise is the bonus: your callsign, your initials, anything that makes your repeater easy to spot in a contact list. The MeshCore Key Generator (https://gessaman.com/mc-keygen/) will grind keys until it finds one starting with the characters you want, entirely in your browser, so your keys never leave your device.

To apply a key from it, connect through USB serial or log in to the repeater from a companion node and run:

`Fda5
`=
set prv.key <your_private_key>
reboot
`=
`f

`:prefix-5-verify
>>5. Reboot and Verify

Reboot and confirm the new prefix took.

`Fda5
`=
reboot
get public.key
`=
`f

The first four hex characters should be the prefix you claimed. Back up this new key as well, since it replaced the key from step 2.

`Fda5
`=
get prv.key
`=
`f

To restore a saved key later, paste it back and reboot:

`Fda5
`=
set prv.key <128_hex_characters>
reboot
`=
`f

The firmware validates the key before accepting it and replies `Fda5OK, reboot to apply! New pubkey: ...`f. If you see `Fda5Error, bad key`f, check you copied all 128 characters.

<
-
Previous: `F79d`_`[Regions`:/page/meshcore/repeater-setup/regions.mu]`_`f
Next: `F79d`_`[Delay Profiles`:/page/meshcore/repeater-setup/delay-profiles.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/#claim-a-unique-public-key-prefix
