#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup.mu]`_`f

`:delay-profiles
>Delay Profiles

Higher elevation nodes wait longer before retransmitting, letting local nodes handle nearby traffic first. The network self-organizes without manual routing. Choose the profile that best matches your repeater's location.

`!`F79d`_`[INFRASTRUCTURE`#delay-infrastructure]`_`f`!
   Typical site: Water tower, cell tower, commercial rooftop
   Neighbors: 20+
   `Fda5txdelay`f: 2
   `Fda5direct.txdelay`f: 2
   `Fda5rxdelay`f: 3

`!`F79d`_`[ELEVATED`#delay-elevated]`_`f`!
   Typical site: Grain elevator, silo, tall barn
   Neighbors: 10–20
   `Fda5txdelay`f: 1.5
   `Fda5direct.txdelay`f: 1
   `Fda5rxdelay`f: 3

`!`F79d`_`[SUBURBAN`#delay-suburban]`_`f`!
   Typical site: Typical rooftop
   Neighbors: 5–10
   `Fda5txdelay`f: 0.8
   `Fda5direct.txdelay`f: 0.4
   `Fda5rxdelay`f: 3

`!`F79d`_`[LOCAL`#delay-local]`_`f`!
   Typical site: Indoor, ground level, low roof
   Neighbors: 1–3
   `Fda5txdelay`f: 0.3
   `Fda5direct.txdelay`f: 0.1
   `Fda5rxdelay`f: 3

`!`F79d`_`[MOBILE`#delay-mobile]`_`f`!
   Typical site: Vehicle, hiking, bike
   Neighbors: varies
   `Fda5txdelay`f: 2
   `Fda5direct.txdelay`f: 2
   `Fda5rxdelay`f: 3

`:delay-infrastructure
>>INFRASTRUCTURE: Highest Elevation

Tall fixed infrastructure such as water towers, cell towers, or commercial rooftops with clear line of sight across the area. Backbone of the MichMesh network (e.g. W8CMN sites).

`Fda5
`=
set txdelay 2
set direct.txdelay 2
set rxdelay 3
`=
`f

`:delay-elevated
>>ELEVATED: Mid Elevation

Grain elevators, tall barns, silos, or other rural structures with moderate height advantage. Bridges infrastructure nodes to suburban coverage.

`Fda5
`=
set txdelay 1.5
set direct.txdelay 1
set rxdelay 3
`=
`f

`:delay-suburban
>>SUBURBAN: Average Elevation

Typical rooftop install serving a neighborhood.

`Fda5
`=
set txdelay 0.8
set direct.txdelay 0.4
set rxdelay 3
`=
`f

`:delay-local
>>LOCAL: Low Elevation

Indoor, ground-level, or low roof. Only sees a few neighbors.

`Fda5
`=
set txdelay 0.3
set direct.txdelay 0.1
set rxdelay 3
`=
`f

`:delay-mobile
>>MOBILE: Variable Elevation

Vehicle, hiking, bike. Always defers to fixed infrastructure.

`Fda5
`=
set txdelay 2
set direct.txdelay 2
set rxdelay 3
`=
`f

<
-
Previous: `F79d`_`[Claim a Unique Public Key Prefix`:/page/meshcore/repeater-setup/claim-a-unique-public-key-prefix.mu]`_`f
Next: `F79d`_`[Settings Reference`:/page/meshcore/repeater-setup/settings-reference.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/#delay-profiles
