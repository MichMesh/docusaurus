#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup.mu]`_`f

`:full-settings-audit
>Full Settings Audit

A deeper audit than the setup steps. Run this before and after a field install to verify everything persisted.

You do not need to be at the repeater for most of this. A companion node logged in as admin can run it over the mesh. Only `Fda5stats-core`f, `Fda5stats-radio`f and `Fda5stats-packets`f need a direct USB connection.

`!Serial connection settings:`! 115200 baud, 8 data bits, 1 stop bit, no parity, no flow control. The line ending has to include a carriage return, so CR or CRLF both work. LF on its own does not: the firmware discards it and your command never runs.

`:audit-identify
>>Identify and Time-Sync

`Fda5
`=
ver
board
clock
clock sync
`=
`f

`:audit-radio
>>Confirm Radio and Identity

`Fda5
`=
get name
get role
get radio
get tx
get dutycycle
get repeat
get path.hash.mode
get loop.detect
get public.key
`=
`f

`:audit-regions
>>Check Regions

`Fda5
`=
region
region default
get flood.max.unscoped
`=
`f

Every line of `Fda5region`f should end in `Fda5F`f, `Fda5region default`f should be `Fda5<null>`f, and `Fda5flood.max.unscoped`f should be `Fda564`f. Anything else is left over from scoping; see `F79d`_`[Undo Scoping Changes`:/page/meshcore/repeater-setup/regions.mu`anchor=undo-scoping]`_`f.

From the app, `!Discover Regions (Scan Local)`! should show every nearby configured repeater reporting `Fda5mi`f and its ancestry.

`:audit-location
>>Check Location and Adverts

`Fda5
`=
get lat
get lon
get advert.interval
get flood.advert.interval
get flood.max
get flood.max.advert
`=
`f

`:audit-delay
>>Audit Owner and Delay Tuning

`Fda5
`=
get owner.info
get rxdelay
get txdelay
get direct.txdelay
`=
`f

`:audit-health
>>Observe Health and Neighbors

`Fda5
`=
stats-core
stats-radio
stats-packets
discover.neighbors
neighbors
`=
`f

`:audit-optional
>>Optional Site-Specific Checks

Only run these when the hardware or install actually uses bridge mode, GPS, or power-saving.

`Fda5
`=
# Bridge parameters
get bridge.enabled
get bridge.delay
get bridge.source
get bridge.baud

# GPS state
gps on
gps sync
gps off

# Power saving
powersaving on
powersaving off
`=
`f

-

`*This guide is adapted from the Colorado Mesh Repeater Setup Guide (https://meshcore.coloradomesh.org/guides/repeater-setup), with additional recommendations from the Bay Area MeshCore Repeater Setup Guide (https://bayareameshcore.org/repeater-setup/) and the PugetMesh Repeater Setup Guide (https://pugetmesh.org/meshcore/repeater_setup/). Region guidance comes from the Michigan MeshCore Regions RFC (https://github.com/MichMesh/MC-Regional-Infrastructure-Planning). Thank you to the Colorado Mesh, Bay Area MeshCore and PugetMesh communities for the thorough documentation.`*

<
-
Previous: `F79d`_`[Settings Reference`:/page/meshcore/repeater-setup/settings-reference.mu]`_`f
Next: `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/#full-settings-audit
