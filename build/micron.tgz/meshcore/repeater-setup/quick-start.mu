#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup.mu]`_`f

`:quick-start
>Quick Start

The full setup for a new repeater on firmware 1.16 or later. Replace everything in `Fda5<angle brackets>`f, and swap the region line for your area (see `F79d`_`[Pick Your Regions`:/page/meshcore/repeater-setup/regions.mu`anchor=pick-your-regions]`_`f). Each block links to a step below that explains it.

`Fda5
`=
# 1. Confirm firmware and radio (expect role = Repeater, 910.525 / 62.5 / 7 / 5)
ver
get role
get radio

# 2. Identity and security
set name <YourRepeaterName>
set lat <42.7336>
set lon <-84.5555>
set owner.info <your_contact_details>|michmesh.com/mcr
password <your_admin_password>

# 3. Michigan network standards
set path.hash.mode 1
set advert.interval 240
set flood.advert.interval 24
set flood.max 32
set agc.reset.interval 500
set dutycycle 100
set loop.detect moderate

# 4. Regions (Grand Rapids example: use your own subregion / local region)
#    Define them only. Scoping is on hold: no region default, no unscoped cap.
region def midwest mi mi-west grr
region save

# 5. Delay profile (SUBURBAN shown: pick yours from Delay Profiles)
set txdelay 0.8
set direct.txdelay 0.4
set rxdelay 3

# 6. Clock, then reboot and verify
clock sync
reboot
`=
`f

After it reboots, reconnect and run `Fda5clock`f, `Fda5region`f, and `Fda5get public.key`f. Before the repeater goes up, `F79d`_`[check its public key prefix`:/page/meshcore/repeater-setup/claim-a-unique-public-key-prefix.mu]`_`f for collisions.

`!`Fda5Caution: Clock Sync Required`f`!

Repeaters boot with an old date. Without a correct clock, relayed message timestamps will be wrong. With GPS-capable firmware and hardware, run `Fda5gps on`f then `Fda5gps sync`f. Otherwise run `Fda5clock sync`f from the companion app or Web Serial after every reboot or power cycle.

<
-
Previous: `F79d`_`[Before You Start`:/page/meshcore/repeater-setup/before-you-start.mu]`_`f
Next: `F79d`_`[Step-by-Step Setup`:/page/meshcore/repeater-setup/step-by-step-setup.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/#quick-start
