#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup.mu]`_`f

`:settings-reference
>Settings Reference

`:path-hash-mode
>>path.hash.mode: Path ID Size

`!`Fda5Note: Michigan Standard`f`!

Michigan settled on `Fda5path.hash.mode 1`f as of May 20, 2026. Make sure to set this on any repeater, and on your companion too. It sets the ID size on the packets your node floods, including the advert the rest of the mesh uses to learn a path back to you. It has no effect on what your node receives.

Every node has a short ID taken from its public key. As a packet floods across the mesh, each repeater that relays it stamps its own ID into the packet, building up a record of the route it took. That record is what lets the mesh learn a path back. `Fda5path.hash.mode`f sets how many bytes long your ID is in that record.

`t
| Mode | ID size | Possible IDs |
| --- | --- | --- |
| `Fda50`f | 1 byte | 256 |
| `Fda51`f | 2 bytes | 65,536 |
| `Fda52`f | 3 bytes | 16,777,216 |
`t

Repeater firmware still ships on mode `Fda50`f. With only 256 IDs to go around, two repeaters in the same area will sooner or later end up with the same one, and the mesh can no longer tell which of them a path actually goes through. Mode `Fda51`f makes that vanishingly unlikely. The MeshCore CLI reference (https://docs.meshcore.io/cli_commands/#view-or-change-this-nodes-advert-path-hash-size) has the full details.

`:public-key-prefix
>>Public Key Prefix

A repeater stamps itself into a packet's routing path using the leading bytes of its public key (its `!prefix`!) and matches inbound direct packets against that same prefix. `Fda5path.hash.mode`f sets the width: mode `Fda51`f means 2 bytes, so four hex characters out of 65,536 possibilities.

Don't confuse that with the 1-byte prefix apps display. Destination addressing is a fixed 1 byte regardless of `Fda5path.hash.mode`f, and with only 256 values duplicates are routine; the firmware handles them by attempting decryption, so they're cosmetic. The 2-byte path prefix is the one that must be unique: two repeaters sharing it both claim the same path entry and both retransmit. The prefix is part of the keypair, so claiming a different one means generating a new key.

`:txdelay
>>txdelay / direct.txdelay

Controls how long a repeater waits before retransmitting a received packet. The firmware works out `Fda5unit = estimated_airtime × txdelay`f, then picks the actual delay uniformly at random between `Fda50`f and `Fda55 × unit`f. Higher values create a wider random window, meaning more deference to other nodes. `Fda5direct.txdelay`f is the same but for routed point-to-point messages (usually set lower for faster delivery). Both accept `Fda50`f–`Fda52`f; repeater firmware ships at `Fda5txdelay 0.5`f and `Fda5direct.txdelay 0.3`f.

`:rxdelay
>>rxdelay: SNR-Based Path Selection

Only affects flood packets. Direct (point-to-point) packets are always processed immediately. Delays processing of floods based on signal quality (SNR). Strong signal = processed immediately. Weak signal = delayed and likely dropped as a duplicate. The mesh naturally prefers the strongest, cleanest paths without manual routing. It accepts `Fda50`f–`Fda520`f and ships `!off`! (`Fda50`f).

`:agc-reset-interval
>>agc.reset.interval: Radio Deafness Prevention

Periodically resets the LoRa radio's Automatic Gain Control (AGC) to prevent "deafness" caused by strong out-of-band RF interference. Without this, the SX1262 AGC can lock up, clamping the noise floor at -120 dBm and making the repeater unable to hear weaker signals until rebooted. Especially important for repeaters near broadcast towers or other RF sources.

`:dutycycle
>>dutycycle: Airtime Throttle

Repeater firmware ships with an airtime budget factor of `Fda51.0`f. The dispatcher computes `Fda5duty_cycle = 1 / (1 + airtime_factor)`f, so that default works out to `!50%`!: the repeater accrues transmit budget at half of elapsed time and defers sending once it runs dry. The US 915 MHz ISM band has no duty cycle limit, so a repeater left at the default is giving away half its airtime. `Fda5set dutycycle 100`f drives the factor to `Fda50`f and removes the throttle.

`:loop-detect
>>loop.detect: Packet Storm Protection

Before repeating a flood, the repeater counts how many times its own hash already appears in that packet's path and drops the packet once the count hits a threshold. Defaults to `Fda5off`f. The three levels set how many repeats it tolerates, and the threshold tightens as the hash gets wider:

`t
| Level | 1-byte | 2-byte | 3-byte |
| --- | --- | --- | --- |
| `Fda5minimal`f | 4 | 2 | 1 |
| `Fda5moderate`f | 2 | 1 | 1 |
| `Fda5strict`f | 1 | 1 | 1 |
`t

`:advert-interval
>>advert.interval: Local Advert Timer

How often the repeater sends a zero-hop advert, heard only by nodes in direct range. Accepts 60–240 minutes and defaults to `Fda50`f, which is off.

`:flood-advert-interval
>>flood.advert.interval: Network-Wide Advert Timer

How often the repeater floods an advert across the whole mesh, so nodes out of direct range can still find it. Accepts 3–168 hours and defaults to `Fda547`f.

`:flood-max
>>flood.max: Flood Hop Limit

Drops a flood packet once its recorded path has reached this many hops. Repeater firmware defaults to `Fda564`f.

Worth knowing before you tune it: a packet's path field holds 64 bytes total, so at `Fda5path.hash.mode 1`f (2-byte hashes) a flood can only ever carry `!32 hops`! before it runs out of room. Setting `Fda532`f costs nothing and matches what other networks publish, but genuinely bounding flood propagation would need a value well below it. For unscoped traffic, `F79d`_`[flood.max.unscoped`:/page/meshcore/repeater-setup/regions.mu`anchor=flood-max-unscoped]`_`f would do that, but it's `F79d`_`[on hold`:/page/meshcore/repeater-setup/regions.mu`anchor=regions-on-hold]`_`f.

<
-
Previous: `F79d`_`[Delay Profiles`:/page/meshcore/repeater-setup/delay-profiles.mu]`_`f
Next: `F79d`_`[Full Settings Audit`:/page/meshcore/repeater-setup/full-settings-audit.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/#settings-reference
