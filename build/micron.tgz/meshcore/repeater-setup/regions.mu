#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup.mu]`_`f

`:regions
>Regions

Regions let traffic be scoped so it only floods as far as it's useful. A repeater forwards scoped traffic only for regions it carries, so the regions you configure decide what your repeater will pass on. Michigan's region names and county assignments come from the draft Michigan MeshCore Regions RFC (https://github.com/MichMesh/MC-Regional-Infrastructure-Planning), developed by Michigan operators.

`:regions-on-hold
>>Scoping Is On Hold

`!`Fda5Info`f`!

Some repeaters had already started scoping traffic and others hadn't, so operators agreed to keep the mesh open for now. Until the group decides otherwise:

 • `!Define regions on repeaters`! with `Fda5region def`f and `Fda5region save`f, as below.
 • `!Don't`! set `Fda5region default`f, set `Fda5flood.max.unscoped`f, or use `Fda5region denyf`f.
 • `!Don't`! set a default scope or channel scopes on companions.

Already changed something? See `F79d`_`[Undo Scoping Changes`#undo-scoping]`_`f for repeaters and `F79d`_`[Undo Region Scoping`:/page/meshcore/getting-started.mu`anchor=undo-region-scoping]`_`f for companions.

`:region-hierarchy
>>The Michigan Hierarchy

`Fda5
`=
midwest
└── mi
    ├── mi-west
    │   ├── grr        Grand Rapids
    │   ├── azo        Kalamazoo
    │   └── mkg        Muskegon (example)
    ├── mi-central
    │   ├── thumb
    │   └── midstate
    ├── mi-east
    │   └── det        Detroit (example)
    ├── mi-north       Northern Lower Peninsula
    │   └── tvc        Traverse City (example)
    └── mi-upper       Upper Peninsula
        └── mqt        Marquette (example)
`=
`f

Local regions marked `*example`* aren't settled yet. Check with operators near you before carrying one, and if your area doesn't have a local region, stop at the subregion.

`:pick-your-regions
>>Pick Your Regions

A repeater carries `!every level`! above it: `Fda5midwest`f, `Fda5mi`f, its subregion, and its local region if there is one. MeshCore does not inherit regions, so each one has to be configured. Find your county below for a default subregion:

`!`Fda5mi-west`f`!
   Counties: Allegan, Barry, Berrien, Branch, Calhoun, Cass, Ionia, Kalamazoo, Kent, Montcalm, Muskegon, Newaygo, Oceana, Ottawa, St. Joseph, Van Buren

`!`Fda5mi-central`f`!
   Counties: Arenac, Bay, Clinton, Eaton, Genesee, Gladwin, Gratiot, Hillsdale, Huron, Ingham, Iosco, Isabella, Jackson, Midland, Ogemaw, Saginaw, Sanilac, Shiawassee, Tuscola

`!`Fda5mi-east`f`!
   Counties: Lapeer, Lenawee, Livingston, Macomb, Monroe, Oakland, St. Clair, Washtenaw, Wayne

`!`Fda5mi-north`f`!
   Counties: Alcona, Alpena, Antrim, Benzie, Charlevoix, Cheboygan, Clare, Crawford, Emmet, Grand Traverse, Kalkaska, Lake, Leelanau, Manistee, Mason, Mecosta, Missaukee, Montmorency, Osceola, Oscoda, Otsego, Presque Isle, Roscommon, Wexford

`!`Fda5mi-upper`f`!
   Counties: Alger, Baraga, Chippewa, Delta, Dickinson, Gogebic, Houghton, Iron, Keweenaw, Luce, Mackinac, Marquette, Menominee, Ontonagon, Schoolcraft

The county table is a starting point, not a border. A repeater carries the subregion of the area it `!actually covers`!: a hilltop site in Ionia County whose footprint is mostly Grand Rapids belongs in `Fda5mi-west`f and `Fda5grr`f. If operators in your area have agreed on something different, that agreement wins.

Examples:

`t
| Repeater | Command |
| --- | --- |
| Grand Rapids | `Fda5region def midwest mi mi-west grr`f |
| Kalamazoo | `Fda5region def midwest mi mi-west azo`f |
| Lansing | `Fda5region def midwest mi mi-central`f |
| Detroit | `Fda5region def midwest mi mi-east`f |
| Traverse City | `Fda5region def midwest mi mi-north`f |
| Marquette | `Fda5region def midwest mi mi-upper`f |
`t

`:undo-scoping
>>Undo Scoping Changes

If you followed an earlier version of this guide, your repeater may have a default scope or an unscoped cap. Leave the regions you defined in place and run:

`Fda5
`=
region default <null>
set flood.max.unscoped 64
`=
`f

Both save immediately, so no reboot is needed. `Fda564`f is the firmware default, which means no cap.

If you also blocked unscoped traffic with `Fda5region denyf *`f, reopen it. Unlike the two commands above, `Fda5allowf`f needs a `Fda5region save`f:

`Fda5
`=
region allowf *
region save
`=
`f

Then check it:

`Fda5
`=
region default
get flood.max.unscoped
region
`=
`f

Expect `Fda5default scope is <null>`f, `Fda5> 64`f, and a tree where every line, including the top `Fda5*`f line, ends in `Fda5F`f:

`Fda5
`=
* F
 midwest F
  mi F
   mi-west F
    grr F
`=
`f

`:region-default
>>Default Scope (On Hold)

`Fda5region default <region>`f would scope the repeater's own adverts to that region. It's `F79d`_`[on hold`#regions-on-hold]`_`f, so don't set it.

`:flood-max-unscoped
>>Unscoped Cap (On Hold)

`Fda5set flood.max.unscoped <hops>`f would drop traffic with no region once it had travelled that many hops. It's `F79d`_`[on hold`#regions-on-hold]`_`f, so leave it at the firmware default of `Fda564`f.

Scoped traffic only travels through repeaters that carry its region, so a mesh where some repeaters scope and others don't loses messages in between. That's why these wait until everyone moves together.

`:region-boundary
>>Repeaters on a Boundary

A repeater can carry more than one subregion. A site on the `Fda5mi-west`f / `Fda5mi-central`f line that really serves both can carry both, and then it forwards traffic scoped to either. That makes it a `!bridge`!, and bridges are a network decision, not a site decision:

 • Carry a neighboring subregion only if you serve companions there. Hearing a neighbor's repeater on a good day isn't coverage.
 • A few deliberate bridges per boundary, announced in the group, beat every edge repeater quietly carrying both.

`Fda5
`=
region def midwest mi mi-west grr
region def midwest mi mi-central
region save
`=
`f

`:region-companion
>>Companion Settings

Companion region setup, and how to undo a default scope or channel scope set earlier, is on `F79d`_`[Getting Started`:/page/meshcore/getting-started.mu`anchor=set-your-region]`_`f, with screenshots for both apps.

<
-
Previous: `F79d`_`[Step-by-Step Setup`:/page/meshcore/repeater-setup/step-by-step-setup.mu]`_`f
Next: `F79d`_`[Claim a Unique Public Key Prefix`:/page/meshcore/repeater-setup/claim-a-unique-public-key-prefix.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/#regions
