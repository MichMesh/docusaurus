#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup.mu]`_`f

`:step-by-step-setup
>Step-by-Step Setup

`:step-1-firmware
>>1. Confirm Firmware and Role

Repeater firmware sets the role automatically. You should see `Fda5role = Repeater`f. If `Fda5ver`f shows a version older than 1.16, upgrade (https://flasher.meshcore.io/) before going further: the region commands in this guide need it.

`Fda5
`=
ver
board
get role
`=
`f

`:step-2-radio
>>2. Verify Radio Settings

Read back the radio configuration and confirm it matches the Michigan preset. If you selected `!USA/Canada (Recommended)`! in the web flasher (https://flasher.meshcore.io/), it already does:

`t
| Setting | Value |
| --- | --- |
| Frequency (MHz) | 910.525 |
| Bandwidth (kHz) | 62.5 |
| Spreading factor | 7 |
| Coding rate | 5 |
`t

`Fda5
`=
get radio
get tx
`=
`f

Only if the read-back didn't match, set them manually:

`Fda5
`=
set radio 910.525,62.5,7,5
set tx <power>
`=
`f

`:step-3-name
>>3. Set Name and Location

Set the name the rest of the mesh will see, and the repeater's coordinates. Location isn't required, but it's what lets everyone see where coverage already exists and where the gaps are. Coordinates are decimal degrees, not degrees/minutes/seconds.

`Fda5
`=
set name <YourRepeaterName>
set lat <42.7336>
set lon <-84.5555>
`=
`f

`:step-4-owner
>>4. Set Owner Info

Free-text contact details so somebody can reach you about the node: an email address, a Discord handle, an amateur radio callsign, or whatever else will actually reach you. Optional, but a repeater nobody can contact is a repeater nobody can tell you is misbehaving. `Fda5|`f characters become line breaks.

`Fda5
`=
set owner.info <your_contact_details>|michmesh.com/mcr
`=
`f

End it with `Fda5|michmesh.com/mcr`f, a short link to this page, so anyone who looks up your repeater can find the Michigan setup standard. Keep the link in owner info rather than the repeater name: once location is set, adverts only carry the first 23 characters of the name, and the link would crowd out or truncate it.

`:step-5-password
>>5. Set an Admin Password

Repeater firmware ships with the admin password set to the literal string `Fda5password`f. Until you change it, anyone in radio range can log in over the mesh and reconfigure your node. Change it before the repeater goes up.

`Fda5
`=
password <your_admin_password>
`=
`f

Leave `Fda5guest.password`f alone on purpose. It defaults to blank, which is what lets community members log in as guests and query repeater status.

`:step-6-standards
>>6. Apply Michigan Network Standards

These apply to every Michigan repeater regardless of location or height.

`Fda5
`=
set path.hash.mode 1
set advert.interval 240
set flood.advert.interval 24
set flood.max 32
set agc.reset.interval 500
set dutycycle 100
set loop.detect moderate
`=
`f

 • `F79d`_`[path.hash.mode 1`:/page/meshcore/repeater-setup/settings-reference.mu`anchor=path-hash-mode]`_`f: 2-byte path hashes. Michigan standard since May 20, 2026; set it on your companion too.
 • `F79d`_`[advert.interval 240`:/page/meshcore/repeater-setup/settings-reference.mu`anchor=advert-interval]`_`f: local advert every 4 hours (neighbors only)
 • `F79d`_`[flood.advert.interval 24`:/page/meshcore/repeater-setup/settings-reference.mu`anchor=flood-advert-interval]`_`f: network-wide advert every 24 hours
 • `F79d`_`[flood.max 32`:/page/meshcore/repeater-setup/settings-reference.mu`anchor=flood-max]`_`f: drops floods past 32 hops to match `Fda5path.hash.mode 1`f
 • `F79d`_`[agc.reset.interval 500`:/page/meshcore/repeater-setup/settings-reference.mu`anchor=agc-reset-interval]`_`f: resets radio AGC every ~8 min to prevent deafness from RF interference
 • `F79d`_`[dutycycle 100`:/page/meshcore/repeater-setup/settings-reference.mu`anchor=dutycycle]`_`f: removes the 50% airtime throttle the repeater firmware ships with
 • `F79d`_`[loop.detect moderate`:/page/meshcore/repeater-setup/settings-reference.mu`anchor=loop-detect]`_`f: drops a flood that already carries this repeater's hash

`:step-7-regions
>>7. Set Regions

Define the full region ancestry for the area the repeater serves. See `F79d`_`[Regions`:/page/meshcore/repeater-setup/regions.mu]`_`f for what to carry.

`Fda5
`=
region def midwest mi <subregion> <local_region>
region save
`=
`f

Leave off `Fda5<local_region>`f if your area doesn't have one yet. Don't set a default scope or cap unscoped floods: `F79d`_`[scoping is on hold`:/page/meshcore/repeater-setup/regions.mu`anchor=regions-on-hold]`_`f. If you already did, `F79d`_`[undo it`:/page/meshcore/repeater-setup/regions.mu`anchor=undo-scoping]`_`f.

`:step-8-delay
>>8. Pick a Delay Profile

Choose the `F79d`_`[delay profile`:/page/meshcore/repeater-setup/delay-profiles.mu]`_`f that matches the repeater's elevation and apply its three commands.

`:step-9-clock
>>9. Sync the Clock

`Fda5
`=
# GPS-capable firmware + hardware:
gps on
gps sync

# Otherwise: companion app or Web Serial, after every reboot:
clock sync
`=
`f

`:step-10-verify
>>10. Reboot and Verify

Reboot, reconnect serial, then confirm settings persisted, the regions took, and time is correct.

`Fda5
`=
reboot
clock
get role
get path.hash.mode
region
region default
get flood.max.unscoped
`=
`f

`Fda5region default`f should answer `Fda5default scope is <null>`f and `Fda5get flood.max.unscoped`f should answer `Fda5> 64`f, the firmware default.

<
-
Previous: `F79d`_`[Quick Start`:/page/meshcore/repeater-setup/quick-start.mu]`_`f
Next: `F79d`_`[Regions`:/page/meshcore/repeater-setup/regions.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/#step-by-step-setup
