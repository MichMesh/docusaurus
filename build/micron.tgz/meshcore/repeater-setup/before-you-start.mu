#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Repeater Setup`:/page/meshcore/repeater-setup.mu]`_`f

`:Before-You-Start
>Before You Start

 • `!Flash Repeater firmware`! via the web flasher (https://flasher.meshcore.io/). Use a Chromium-based browser, since the flasher needs the Web Serial API. This guide requires firmware `!1.16 or later`!; if a repeater is running anything older, upgrade it first.
 • `!Mount high with line of sight`! and use a real external antenna. Elevation and antenna quality matter more than transmit power.
 • `!Use a stable power supply`!: wall adapter, POE, or solar with battery backup. Avoid bus-powered USB hubs.
 • `!Connect over USB`! with the Web Serial console at config.meshcore.io (https://config.meshcore.io).

`!`Fda5Note: nRF52 boards only: Install OTAFIX`f`!

Flash OTAFIX (https://github.com/oltaco/Adafruit_nRF52_Bootloader_OTAFIX) before the repeater firmware as it falls back to DFU mode when an OTA update fails. See the install instructions here (https://blog.meshcore.io/2026/04/06/otafix-bootloader).

`!`Fda5Warning: CLI Syntax`f`!

The MeshCore CLI uses `!spaces`!, not `Fda5=`f. Typing `Fda5set path.hash.mode = 1`f can silently fail or store garbage. Always use `Fda5set path.hash.mode 1`f.

<
-
Previous: `F79d`_`[Repeater Setup Guide`:/page/meshcore/repeater-setup.mu]`_`f
Next: `F79d`_`[Quick Start`:/page/meshcore/repeater-setup/quick-start.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Repeater-Setup/#Before-You-Start
