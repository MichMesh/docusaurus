#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:learn-more
>Learn More

MeshCore's own guides suggest setting a default scope right away. In Michigan, that becomes the recommendation at step 2 of the rollout; until then, keep it blank unless you're experimenting.

 • MeshCore documentation (https://docs.meshcore.io/) and command reference (https://docs.meshcore.io/cli_commands/), for technical details
 • MeshCore blog: region filtering (https://blog.meshcore.io/2026/01/20/region-filtering) and default scope (https://blog.meshcore.io/2026/04/17/default-scope)
 • MeshCore on GitHub (https://github.com/meshcore-dev/MeshCore): source code, releases and proposals
 • RFC-001 and Addendum A (https://github.com/MichMesh/MC-Regional-Infrastructure-Planning): Michigan's region names, county assignments and draft scoping policy
 • Pacific Northwest region rollout (https://gessaman.com/meshcore/regions/rollout/): how another community staged it

<
-
Previous: `F79d`_`[Open Items`:/page/meshcore/regions-and-scoping/open-items.mu]`_`f
Next: `F79d`_`[Change History`:/page/meshcore/regions-and-scoping/change-history.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#learn-more
