#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:why-the-names
>Why the Names Look Like This

`!Each step down the tree is a smaller area.`! Once tagging is done, every Michigan repeater carries `Fda5midwest`f and `Fda5mi`f, but only repeaters around Detroit, Ann Arbor and Port Huron carry `Fda5mi-east`f, only Upper Peninsula repeaters carry `Fda5mi-upper`f, and only repeaters around Kalamazoo carry `Fda5azo`f. So the smaller the region, the fewer repeaters pass the message on and the shorter it spreads:

`!`Fda5midwest`f`!
   Passed on by, once tagged: Every Michigan repeater, and neighbors' repeaters that carry it
   Reaches: Across state lines

`!`Fda5mi`f`!
   Passed on by, once tagged: Every Michigan repeater
   Reaches: The whole state

`!A subregion: `Fda5mi-west`f, `Fda5mi-central`f, `Fda5mi-east`f, `Fda5mi-north`f, `Fda5mi-upper`f`!
   Passed on by, once tagged: Repeaters in that part of the state
   Reaches: That part of Michigan

`!A local region, like `Fda5grr`f (Grand Rapids) or `Fda5azo`f (Kalamazoo)`!
   Passed on by, once tagged: Repeaters serving that area
   Reaches: That metro area

When scoping starts, the idea is to pick the smallest region that still reaches the people you're talking to.

`!Why `Fda5mi-west`f and not just `Fda5west`f.`! A region name means the same thing everywhere. If Michigan's subregions were plain `Fda5west`f, `Fda5east`f or `Fda5north`f, our repeaters would pass messages scoped to those names from any mesh that used them, whether across Lake Michigan, in Ohio or Ontario, or across the UP's border with Wisconsin, and our messages would ride their repeaters too. The `Fda5mi-`f prefix makes Michigan's subregions Michigan's alone. Local names need the same care, so check a new one against Michigan's region naming plan (https://github.com/MichMesh/MC-Regional-Infrastructure-Planning) (RFC-001) and with nearby operators before using it.

`!Why `Fda5midwest`f sits on top.`! Some messages are meant to cross state lines. Giving them their own scope, coordinated with neighboring meshes, keeps that traffic from riding `Fda5mi`f or going out unscoped.

<
-
Previous: `F79d`_`[Why Scoping Matters`:/page/meshcore/regions-and-scoping/why.mu]`_`f
Next: `F79d`_`[Where Michigan Stands`:/page/meshcore/regions-and-scoping/where-we-are.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#why-the-names
