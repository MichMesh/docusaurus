#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:faq
>FAQ

`:faq-companions
>>For Companion Users

`!What should I set on my phone right now?`!

Nothing is required. Unscoped messages reach everyone. Experimenting with a scoped channel is fine; keep your default scope blank so your adverts and direct messages aren't affected. `F79d`_`[Getting Started`:/page/meshcore/getting-started.mu`anchor=undo-region-scoping]`_`f shows how to clear a scope in each app.

`!Wouldn't setting `Fda5mi`f keep my messages in Michigan, or help them reach farther?`!

Not yet. Today it mostly costs reach: not every Michigan repeater carries `Fda5mi`f yet, and any that doesn't will drop your message, while every repeater passes unscoped messages. It's fine to try, just expect some messages not to arrive until tagging is done.

`!What will change for me when unscoped messages are limited?`!

Nothing yet. When step 2 starts, messages with no scope only reach people within about three repeaters, so you'll set a default scope to keep reaching the rest of the state. It'll be announced first, with the settings to make; `F79d`_`[Step 2: What Changes`:/page/meshcore/regions-and-scoping/the-plan.mu`anchor=when-limited]`_`f has the details.

`!If I set a scope, will I stop seeing messages from other areas?`!

No. A scope only affects what you send. Your radio still hears everything that reaches it.

`!Does scoping make my channel private?`!

No. A scope only limits which repeaters pass a message on. Only your channel key keeps a message private.

`!Is a channel named `Fda5#michigan`f automatically scoped to `Fda5mi`f?`!

No. A channel's name and its scope are separate settings. A channel shared by QR code or link can bring a scope with it, though, so check the channel's scope after you join one so you know what you're sending with.

`:faq-repeaters
>>For Repeater Operators

`!Why tag repeaters now?`!

Defining regions only adds: your repeater can now pass scoped messages for those regions, and unscoped messages work exactly as before. Tagging every repeater now means that as scoped messages become common, nobody gets cut off.

`!Why does my repeater carry three or four regions instead of one?`!

Each level is a different reach a sender can pick: a local region for the metro area, a subregion for your part of the state, `Fda5mi`f for statewide, `Fda5midwest`f for across state lines. A repeater missing a level is a dead end for messages scoped to it. Most repeaters carry three (`Fda5midwest mi mi-east`f), or four where their area uses a local region (`Fda5midwest mi mi-west azo`f).

`!Will defining regions stop out-of-state traffic, like what crosses Lake Michigan from Chicago?`!

No. That traffic is unscoped, and regions only affect scoped messages. Limiting unscoped traffic is `F79d`_`[step 2`:/page/meshcore/regions-and-scoping/the-plan.mu`anchor=when-limited]`_`f of the rollout.

`!What should the `Fda5region`f output look like?`!

It should list `Fda5midwest`f, `Fda5mi`f, your subregion and any local region, and every line, including the top one, should end in `Fda5F`f. Repeater Setup's `F79d`_`[Check Regions`:/page/meshcore/repeater-setup/full-settings-audit.mu`anchor=audit-regions]`_`f has an example.

`!Should I copy the whole tree onto my repeater?`!

No. Carry exactly your own regions. Every extra region lets your repeater pass messages scoped to it from anywhere, and carrying a second subregion makes your site a `F79d`_`[bridge`:/page/meshcore/repeater-setup/regions.mu`anchor=region-boundary]`_`f, which is a group decision.

`!My regions disappeared after a reboot. What happened?`!

`Fda5region def`f takes effect right away but isn't kept unless you run `Fda5region save`f. On firmware 1.16, a save can fail and still answer `Fda5OK`f, so update to the latest release. Also check the spelling: region names are exact, so `Fda5Mi`f or `Fda5mi-wset`f is a different region nobody else carries.

`!Discover Regions doesn't show my repeater. Why?`!

Discover Regions only asks repeaters your radio hears directly, and each repeater answers only a few requests every few minutes, so wait and try again. Use the steps in `F79d`_`[Add Regions to Your App`:/page/meshcore/getting-started.mu`anchor=add-regions-to-app]`_`f so you don't set a default scope by accident.

`!Will any of this change?`!

MeshCore is still adding region features, so details may change. This page gets rechecked before each step of the rollout. Follow the MeshCore blog (https://blog.meshcore.io/) for what's new.

<
-
Previous: `F79d`_`[What To Do Now`:/page/meshcore/regions-and-scoping/what-to-do-now.mu]`_`f
Next: `F79d`_`[The Rollout`:/page/meshcore/regions-and-scoping/the-plan.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#faq
