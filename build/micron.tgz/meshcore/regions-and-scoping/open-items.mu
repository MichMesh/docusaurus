#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:open-items
>Open Items

 • Coordinating `Fda5midwest`f with neighboring meshes, so it's a deliberate choice there too and not a default.

<
-
Previous: `F79d`_`[The Map and Names`:/page/meshcore/regions-and-scoping/the-map.mu]`_`f
Next: `F79d`_`[Learn More`:/page/meshcore/regions-and-scoping/learn-more.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#open-items
