#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:where-we-are
>Where Michigan Stands

`!Every Michigan repeater should be tagged now`!, with `Fda5midwest`f, `Fda5mi`f, its subregion, and a local region if its area uses one. Regions follow the coverage a repeater actually serves, not a county line. Repeaters change no other region settings. Companions stay unscoped by default, and anyone can experiment with scoped messages.

Repeaters need firmware `!1.16 or later`!. For repeaters and companions alike, the latest release is best. Update from the web flasher (https://flasher.meshcore.io/).

<
-
Previous: `F79d`_`[Why the Names Look Like This`:/page/meshcore/regions-and-scoping/why-the-names.mu]`_`f
Next: `F79d`_`[What To Do Now`:/page/meshcore/regions-and-scoping/what-to-do-now.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#where-we-are
