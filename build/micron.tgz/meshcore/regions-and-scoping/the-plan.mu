#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:the-plan
>The Rollout

Michigan is rolling regions out in steps. Each one starts when operators agree the last one is done, and it's announced before it starts.

 1. `!Tag every repeater`! (now). Every repeater carries all its regions, so nobody gets cut off when scoped messages start.
 2. `!Limit how far unscoped messages travel`! (next). Companions set a default scope, and every repeater stops passing an unscoped message after it has been repeated 3 times, starting with tall, well-connected sites. Sparse areas, like much of the northern Lower Peninsula and the UP, can leave the limit off until coverage fills in. `F79d`_`[What changes`#when-limited]`_`f is below.
 3. `!Stop passing unscoped messages`! (later, optional). Only once most companions in an area have a default scope, and only coordinated with neighboring repeaters.

The steps follow RFC-001 Addendum A (https://github.com/MichMesh/MC-Regional-Infrastructure-Planning/blob/main/rfc/0001-addendum-a-scoping-and-county-reference.md), Michigan's draft scoping policy, with one change: repeaters don't set a `Fda5region default`f. Where the two differ, follow this page.

`:when-limited
>>Step 2: What Changes

When step 2 starts, an unscoped message only travels about three repeaters from where it started. Scoped messages aren't limited.

`!If your companion has no scope set:`!

 • Your messages and adverts still reach people near you, within about three repeaters.
 • People farther away won't get your channel messages or see you show up in their contacts, and a first message to someone far away won't reach them.
 • Messages to people you've already reached usually follow a saved route, and those aren't affected.

`!If you've set a default scope of `Fda5mi`f`! and the channel scopes below:

 • Your messages travel as far as repeaters carry their scope: the whole state for `Fda5mi`f, your part of the state for a subregion.
 • One catch: delivery confirmations come back with the `*other person's`* scope. If they haven't set one, a message to someone far away can arrive but show as failed on your end.

`!For everyone:`!

 • Out-of-state noise, like the traffic from Chicago, dies out within a few repeaters instead of crossing the state.
 • In sparse areas where the nearest people are more than three repeaters away, operators may leave the limit off.
 • Operators will announce it before it starts, along with the companion settings to make.

`!Companion settings for step 2.`! These become the recommendation when step 2 is announced; you can try them sooner, knowing some messages won't arrive until every repeater is tagged. A default scope of `Fda5mi`f, plus channel scopes:

`!Statewide, like `Fda5#michigan`f`!
   Scope: `Fda5mi`f

`!Regional, like `Fda5#wmi`f`!
   Scope: that subregion, e.g. `Fda5mi-west`f

`!Local, like `Fda5#grr`f or `Fda5#azo`f`!
   Scope: that local region

`!Public`!
   Scope: your local region, or your subregion if your area doesn't have one

MeshCore's own guidance suggests setting a broad default scope right away. Michigan recommends it from step 2, so nobody gets cut off while repeaters are still being tagged.

<
-
Previous: `F79d`_`[FAQ`:/page/meshcore/regions-and-scoping/faq.mu]`_`f
Next: `F79d`_`[The Map and Names`:/page/meshcore/regions-and-scoping/the-map.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#the-plan
