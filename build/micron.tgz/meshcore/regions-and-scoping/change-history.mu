#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:change-history
>Change History

 • 2026-10 — Page created during step 1 of the rollout: repeaters define regions only. The rollout follows RFC-001 Addendum A, without its repeater default scope or its one-week trial of limiting unscoped messages. Firmware 1.16 is the minimum.

<
-
Previous: `F79d`_`[Learn More`:/page/meshcore/regions-and-scoping/learn-more.mu]`_`f
Next: `F79d`_`[HF-Testing`:/page/meshcore/hf-testing.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#change-history
