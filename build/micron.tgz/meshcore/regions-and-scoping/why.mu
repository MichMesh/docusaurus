#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:why
>Why Scoping Matters

`!What this is really about.`! MeshCore is growing fast, and in parts of Europe, meshes that filled in with no scoping got so busy that the local mesh stopped working for the people under it. Detroit, Flint, Lansing, the Tri-Cities, Kalamazoo and Grand Rapids all have repeaters on the air, and as those networks fill in they grow into each other. The goal is to keep the mesh usable for people in their own area by default, and make reaching far-away areas a deliberate choice.

`!Where it showed up first.`! West-side repeaters regularly hear traffic from Chicago, carried across Lake Michigan on days when signals travel unusually far. We hear them but they can't hear us, so it's just noise here, and every repeater that hears it repeats it. Michigan borders Ohio, Indiana, Wisconsin and Ontario too, and the same can happen along any of those edges as meshes there grow.

`!Why regions alone don't fix it.`! That traffic is unscoped, and every repeater passes unscoped messages. Regions only help once there's also a decision about unscoped traffic.

`!Why we don't just block it.`! Every new user starts out unscoped. Blocking unscoped messages would silence them until they set a scope they don't know exists yet. That's the wrong trade for a network that wants to grow.

`!What other meshes learned.`! Where some repeaters were tagged and others weren't, scoped messages got lost in the gaps, and several cities in Poland gave up on scoping for that reason. Some communities tag every repeater before anyone scopes, which is what Michigan is doing.

<
-
Previous: `F79d`_`[How Regions Work`:/page/meshcore/regions-and-scoping/how-regions-work.mu]`_`f
Next: `F79d`_`[Why the Names Look Like This`:/page/meshcore/regions-and-scoping/why-the-names.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#why
