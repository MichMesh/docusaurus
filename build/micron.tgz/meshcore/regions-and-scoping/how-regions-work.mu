#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:how-regions-work
>How Regions Work

Four words do all the work:

 • `!Region`!: a name for an area, like `Fda5mi`f (Michigan), `Fda5mi-central`f (Flint, Lansing, the Tri-Cities) or `Fda5azo`f (Kalamazoo).
 • `!Carry`!: the regions a repeater has defined are the ones it `*carries`*. "Tagging" a repeater means defining its regions. Repeaters are tagged; messages are scoped.
 • `!Scoped`!: a message sent with one region attached. The region on a message is its `!scope`!. In the MeshCore app that's your `*Default Region Scope`* and each channel's `*Region Scope`*; other apps label them differently.
 • `!Unscoped`!: a message with no region attached. That's what you send when those settings are blank, and nearly everything in Michigan today.

What happens to a message depends on whether it has a scope, and on which `F79d`_`[step of the rollout`:/page/meshcore/regions-and-scoping/the-plan.mu]`_`f Michigan is in:

`!`!Unscoped message`! (no region)`!
   Today: Every repeater passes it on
   Once unscoped messages are limited (step 2): Repeaters pass it on about 3 times, then it stops

`!`!Scoped message`! (one region, like `Fda5mi`f)`!
   Today: Only repeaters that carry its region pass it on
   Once unscoped messages are limited (step 2): Same: only repeaters that carry its region, as far as they reach

Tagging a repeater never costs an unscoped message anything; regions only decide which scoped messages get through. `F79d`_`[Step 2: What Changes`:/page/meshcore/regions-and-scoping/the-plan.mu`anchor=when-limited]`_`f has more on the limit.

`!The tree is for us, not the radios.`! Michigan's regions form a tree: `Fda5midwest`f › `Fda5mi`f › one of five subregions (`Fda5mi-west`f, `Fda5mi-central`f, `Fda5mi-east`f, `Fda5mi-north`f, `Fda5mi-upper`f) › sometimes a local region like `Fda5azo`f. It helps people pick names that fit together. The radios don't use it to decide what to pass on: a repeater with `Fda5mi-east`f won't pass a message scoped to `Fda5mi`f unless it has `Fda5mi`f too. So each repeater is given every level, from `Fda5midwest`f down to its own area.

Three more things worth knowing:

 • `!A scope only changes what repeaters pass on.`! Your radio still hears everything that reaches it.
 • `!A scope isn't privacy.`! Your channel key is what keeps a message private.
 • `!One gap stops a scoped message.`! Every repeater that doesn't carry its region drops it, so a scoped message only gets as far as an unbroken line of repeaters that carry it. That's why every repeater gets tagged before scoped messages become the norm.

<
-
Previous: `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f
Next: `F79d`_`[Why Scoping Matters`:/page/meshcore/regions-and-scoping/why.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#how-regions-work
