#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:the-map
>The Map and Names

Reference boundaries for the five subregions, drawn from county groupings. They're reference assignments, not borders: a repeater carries the region of the coverage it actually serves. Local regions follow observed coverage and aren't drawn.

`*[Michigan MeshCore region map]`* https://optimetrics.github.io/mesh-region-map/

Open the map full screen (https://optimetrics.github.io/mesh-region-map/) · Map source and data (https://github.com/Optimetrics/mesh-region-map)

Michigan follows the draft RFC-001: Michigan MeshCore Regions (https://github.com/MichMesh/MC-Regional-Infrastructure-Planning), a proposal written by Michigan operators:

`Fda5
`=
midwest
├── mi
│   ├── mi-west
│   │   ├── grr        Grand Rapids
│   │   ├── mkg        Muskegon (example only)
│   │   └── azo        Kalamazoo
│   ├── mi-central
│   │   ├── thumb      (not settled)
│   │   └── midstate   (not settled)
│   ├── mi-east
│   │   └── det        Detroit (example only)
│   ├── mi-north       Northern Lower Peninsula
│   │   └── tvc        Traverse City (example only)
│   └── mi-upper       Upper Peninsula
│       └── mqt        Marquette (example only)
├── il                 Illinois (example only)
├── wi                 Wisconsin (example only)
└── in                 Indiana (example only)
`=
`f

`!Carry only your own regions, not the whole tree.`! `Fda5grr`f and `Fda5azo`f are the local regions RFC-001 defines so far. `Fda5thumb`f and `Fda5midstate`f are named but not settled, and entries marked `*example only`* show where other local regions and neighboring states would slot in; don't carry them. If your area uses or wants a local region, agree on it with operators nearby and propose it through the RFC (https://github.com/MichMesh/MC-Regional-Infrastructure-Planning).

`!Naming rules.`! Short, lowercase letters, digits and hyphens, with no `Fda5#`f. Spelling must match exactly on every repeater, because a different spelling is a different region.

<
-
Previous: `F79d`_`[The Rollout`:/page/meshcore/regions-and-scoping/the-plan.mu]`_`f
Next: `F79d`_`[Open Items`:/page/meshcore/regions-and-scoping/open-items.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#the-map
