#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshcore`:/page/meshcore/index.mu]`_`f / `F79d`_`[Regions and Scoping`:/page/meshcore/regions-and-scoping.mu]`_`f

`:what-to-do-now
>What To Do Now

`:companion-users
>>Companion Users

Nothing you need to set: with no scope, your messages are unscoped and reach everyone.

Want to try scoped messages? Go ahead. It's easiest on a channel: give it a scope like `Fda5mi`f or your subregion, and keep your default scope blank so your adverts and direct messages still reach everyone. A scoped message only reaches as far as repeaters carry its region, so some won't arrive until every repeater is tagged. If messages stop getting through, or you joined a channel from a QR code or link that brought a scope with it, here's how to `F79d`_`[clear it`:/page/meshcore/getting-started.mu`anchor=undo-region-scoping]`_`f.

You don't need to save region names in your app yet. If you do, follow `F79d`_`[Getting Started`:/page/meshcore/getting-started.mu`anchor=add-regions-to-app]`_`f exactly: in the MeshCore app, tapping a region in that list makes it your default.

`:repeater-operators
>>Repeater Operators

Give your repeater `Fda5midwest`f, `Fda5mi`f, your subregion and, if your area uses one, your local region, then save:

`Fda5
`=
region def midwest mi <subregion> <local_region>
region save
`=
`f

`t
| Part of the state | Regions to carry |
| --- | --- |
| West Michigan | `Fda5midwest mi mi-west`f |
| Central Michigan | `Fda5midwest mi mi-central`f |
| Southeast Michigan | `Fda5midwest mi mi-east`f |
| Northern Lower Peninsula | `Fda5midwest mi mi-north`f |
| Upper Peninsula | `Fda5midwest mi mi-upper`f |
`t

If your area uses a local region, add it to the end, e.g. `Fda5midwest mi mi-west azo`f. If you're not sure, check with operators near you. `F79d`_`[Pick Your Regions`:/page/meshcore/repeater-setup/regions.mu`anchor=pick-your-regions]`_`f has every county, and `F79d`_`[Verify`:/page/meshcore/repeater-setup/step-by-step-setup.mu`anchor=step-10-verify]`_`f shows how to check your work.

<
-
Previous: `F79d`_`[Where Michigan Stands`:/page/meshcore/regions-and-scoping/where-we-are.mu]`_`f
Next: `F79d`_`[FAQ`:/page/meshcore/regions-and-scoping/faq.mu]`_`f
On the web: https://michmesh.com/docs/MeshCore/Regions-and-Scoping/#what-to-do-now
