#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f

>Contact Information

-

-

`:Contact-Information
>Contact Information

Join us at the MichMesh Discord 🌐here (https://discord.gg/3A5RREcBcc) or  Signal on the Main room (https://signal.group/#CjQKIG5-o6UUXvto66c1wN4fbinuguy614cJtRPmMxUA6JWyEhBKp6Q70OkA2MpcjsBYU1r9), the OT room (https://signal.group/#CjQKIDw4Y8LBRO-VeLA8S6mWdj24V-E_FNLsMN16vthOP5zeEhC1NJFgbmh3uEQADOPTfug9), and Dev room (https://signal.group/#CjQKIFyHLu63aHKKLfshInlU7w1ckpYaRyW-BfeT8P1H0RM1EhDdmtD_KgUo8ywPr2Z9oKo0). Chat with us on Reticulum by sending `Fda5/join`f to the MichMesh group chat 🌐`F79d`_`[6e54f24ffb316ce6f5e5217e98664fa7`lxmf@6e54f24ffb316ce6f5e5217e98664fa7]`_`f. See `F79d`_`[Services`:/page/reticulum/services.mu]`_`f for the group chat and our Relay Chat rooms.

Or via MQTT/Meshtastic on the `Fda5Michigan`f channel

DM via Reticulum at

 • yNos Meschat 🖥️ : `F79d`_`[lxmf@0afc7a8cc81c5b644e0f71e550af3f14`lxmf@0afc7a8cc81c5b644e0f71e550af3f14]`_`f
 • yNos phone 📱: `F79d`_`[lxmf@21132ce79197b4b12857b809012cd28b`lxmf@21132ce79197b4b12857b809012cd28b]`_`f

<
-
Previous: `F79d`_`[LoS tools and links`:/page/los-tools-and-links.mu]`_`f
Next: `F79d`_`[Affiliate Groups`:/page/affiliate-groups.mu]`_`f
On the web: https://michmesh.com/docs/Contact/
