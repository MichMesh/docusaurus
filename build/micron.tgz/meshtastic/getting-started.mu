#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshtastic`:/page/meshtastic/index.mu]`_`f

>Getting Started

`:Wait-a-minute-this-is-confusing
>>Wait a minute, this is confusing!

Yeah, there are some terms that get used differently depending on where they are used. Freq channels are also called channel slots or just channels, but general chat channels are also called channels? Yeah, it's a mess. Organic growth in the app and documentation have made things confusing. Don't worry about asking questions if you are unsure - we all had to figure it out and most of us are pretty friendly about answering questions.

`:Do-I-need-to-change-frequencychannel-number-in-order-to-connect-with-other-people
>>Do I need to change frequency/channel number in order to connect with other people?

Most likely, no. The standard `Fda5LongFast`f channel preset will cover your area. Some people are playing with using faster (shorter range) and slower (longer range) channels, but this is usually coordinated and not used long term.

`:MQTT
>>MQTT

If you don't already have an MQTT gateway on your mesh or if you are a mobile node, you may want to setup an MQTT gateway. You likely do `*not`* want to use the `Fda5msh/US`f topic, so let's setup the `Fda5msh/US/MI`f topic.

`:To-Join-the-Michigan-Meshtastic-MQTT-Topic
>>>To Join the Michigan Meshtastic MQTT Topic

 1. iOS: Go to >config>Module configuration - Android: ☰ > Radio Configuration
 2. go to LoRa, enable `Fda5Ok to MQTT`f, click `Fda5Send`f
 3. Click `Fda5MQTT`f
 4. Enable `Fda5MQTT`f

 • If you want to use the MichMesh MQTT server (which is connected to the public Meshtastic MQTT server), change the server name to `Fda5mqtt.michmesh.net`f. The username/password are the same - `Fda5meshdev`f/`Fda5large4cats`f

 5. Scroll to root Topic
 6. Paste `Fda5msh/US/MI`f
 7. Enable Proxy to Client - skip this step if you're using a network connected node like and ESP32 on WiFi or a POE powered WisBlock (This adds a internet connection to the node if you have only Bluetooth connection and not wifi.)
 8. Click save The node will now reboot.

`:Once-its-up-its-time-to-enable-uplinkdownlink-on-your-channels
>>>Once it's up, it's time to enable uplink/downlink on your channels.

 1. iOS: Go to >config>channels - Android: ☰ > Radio Configuration > channels
 2. Click Primary/Default/LongFast Channel
 3. Enable Uplink (if you want to show up on the maps)
 4. Enable Position if you want to send your location out over the mesh.
 5. click Save

`:Adding-the-extra-channels
>>>Adding the extra channels

  │ Michigan

 1. iOS: Go to >config>channels - Android: ☰ > Radio Configuration > channels
 2. Click `Fda5+`f
 3. Channel Name: `Fda5Michigan`f
 4. iOS: Key Size: `Fda51 byte`f
 5. PSK: `Fda5MA==`f - this is case sensitive, it `*must`* be uppercase and without spaces.
 6. Enable Uplink/Downlink
 7. Enable Position if you want to send your location out over the mesh.
 8. click save

  │ Western Michigan

 1. iOS: Go to >config>channels - Android: ☰ > Radio Configuration > channels
 2. Click `Fda5+`f
 3. Channel Name: `Fda5WMI`f
 4. iOS: Key Size: `Fda51 byte`f
 5. PSK: `Fda5MA==`f - this is case sensitive, it `*must`* be uppercase and without spaces.
 6. Enable Uplink/Downlink
 7. Enable Position if you want to send your location out over the mesh.
 8. click save

  │ Eastern Michigan

 1. iOS: Go to >config>channels - Android: ☰ > Radio Configuration > channels
 2. Click `Fda5+`f
 3. Channel Name: `Fda5EMI`f
 4. iOS: Key Size: `Fda51 byte`f
 5. PSK: `Fda5MA==`f - this is case sensitive, it `*must`* be uppercase and without spaces.
 6. Enable Uplink/Downlink
 7. Enable Position if you want to send your location out over the mesh.
 8. click save

  │ Muskegon

 1. iOS: Go to >config>channels - Android: ☰ > Radio Configuration > channels
 2. Click `Fda5+`f
 3. Channel Name: `Fda5Muskegon`f
 4. iOS: Key Size: `Fda51 byte`f
 5. PSK: `Fda5MA==`f - this is case sensitive, it `*must`* be uppercase and without spaces.
 6. Enable Uplink/Downlink
 7. Enable Position if you want to send your location out over the mesh.
 8. click save

  │ Northern LP

 1. iOS: Go to >config>channels - Android: ☰ > Radio Configuration > channels
 2. Click `Fda5+`f
 3. Channel Name: `Fda5NMI`f
 4. iOS: Key Size: `Fda51 byte`f
 5. PSK: `Fda5MA==`f - this is case sensitive, it `*must`* be uppercase and without spaces.
 6. Enable Uplink/Downlink
 7. Enable Position if you want to send your location out over the mesh.
 8. click save

  │ Upper Peninsula

 1. iOS: Go to >config>channels - Android: ☰ > Radio Configuration > channels
 2. Click `Fda5+`f
 3. Channel Name: `Fda5YOOPER`f
 4. iOS: Key Size: `Fda51 byte`f
 5. PSK: `Fda5MA==`f - this is case sensitive, it `*must`* be uppercase and without spaces.
 6. Enable Uplink/Downlink
 7. Enable Position if you want to send your location out over the mesh.
 8. click save

  │ Washtenaw County

 1. iOS: Go to >config>channels - Android: ☰ > Radio Configuration > channels
 2. Click `Fda5+`f
 3. Channel Name: `Fda5Washtenaw`f
 4. iOS: Key Size: `Fda51 byte`f
 5. PSK: `Fda5MA==`f - this is case sensitive, it `*must`* be uppercase and without spaces.
 6. Enable Uplink/Downlink
 7. Enable Position if you want to send your location out over the mesh.
 8. click save

`:After-channel-config
>>>>After channel config

click `Fda5Send`f to push new channels to node.

<
-
Previous: `F79d`_`[What is it?`:/page/meshtastic/index.mu]`_`f
Next: `F79d`_`[OTA Firmware Updates via the Meshtastic App`:/page/meshtastic/ota-meshtastic-updates.mu]`_`f
On the web: https://michmesh.com/docs/Meshtastic/Getting%20Started/
