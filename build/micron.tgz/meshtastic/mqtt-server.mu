#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshtastic`:/page/meshtastic/index.mu]`_`f

`:Installation-and-configuration-of-the-Mosquitto-MQTT-server
>Installation and configuration of the Mosquitto MQTT server

This is based on a debian install, ubuntu should be similar.

 • `Fda5sudo apt install mosquitto`f
 • `Fda5sudo vim /etc/mosquitto/mosquitto.conf`f

`Fda5
`=
pid_file /run/mosquitto/mosquitto.pid

log_dest topic
log_type information
log_type subscribe
log_type unsubscribe

acl_file /etc/mosquitto/aclfile.conf

listener 8883
cafile /etc/letsencrypt/live/ynos.us-0001/chain.pem
keyfile /etc/letsencrypt/live/ynos.us-0001/privkey.pem
certfile /etc/letsencrypt/live/ynos.us-0001/cert.pem


listener 1883
allow_anonymous  false
password_file /etc/mosquitto/passwd

connection me-to-mesh
address mqtt.meshtastic.org:1883
remote_username meshdev
remote_password large4cats
topic msh/US/MI/# both

connection me-to-liam
address mqtt.meshtastic.liamcottle.net:1883
remote_username uplink
remote_password uplink
topic msh/US/MI out
`=
`f

 • `Fda5sudo vim /etc/mosquitto/aclfile.conf`f

`Fda5
`=
# This affects access control for clients with no username.
topic read $SYS/#

# This only affects clients with username "testuser".
user testuser
topic readwrite test/#
#topic read $SYS/#

user meshdev
topic readwrite msh/#
topic read $SYS/#

# This affects all clients.
pattern write $SYS/broker/connection/%c/state
`=
`f

 • `Fda5sudo mosquitto_passwd -c meshdev /etc/mosquitto/passwd`f

password: large4cats

 • `Fda5sudo systemctl enable mosquitto`f
 • `Fda5sudo systemctl restart mosquitto`f

You will have to do a bit of a permissions dance to get certs working. I have it running with a letsencrypt cert, this is what I had to do.

 • create a group called `Fda5certreader`f
 • change the group ownership of the /etc/letsencrypt/archive/ to certreader `Fda5sudo chgrp -R certreader /etc/letsencrypt/archive/$YOURCERTDIR`f

<
-
Previous: `F79d`_`[OTA Firmware Updates via the Meshtastic App`:/page/meshtastic/ota-meshtastic-updates.mu]`_`f
Next: `F79d`_`[Wait, ANOTHER Mesh?`:/page/meshcore/index.mu]`_`f
On the web: https://michmesh.com/docs/Meshtastic/mqtt%20server/
