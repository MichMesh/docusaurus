#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Meshtastic`:/page/meshtastic/index.mu]`_`f

`:OTA-Firmware-Updates-via-the-Meshtastic-App
>OTA Firmware Updates via the Meshtastic App

The Meshtastic app now includes `!built-in firmware update support`! for nRF52, ESP32, and USB DFU-compatible devices. You no longer need the separate Nordic DFU Utility or nRF Connect app.

-

`:Before-You-Start
>>Before You Start

 • Make sure your Meshtastic app is `!v2.7.8 or newer`! (check the Google Play or iOS Store for updates)
 • Plug your phone in or ensure it has plenty of battery — updates can take several minutes
 • Keep your phone `!awake`! during the update (on Android you can go to `!Settings > Developer Options > Stay Awake`! while charging)

`!`Fda5Tip`f`!

If you don't see Developer Options, go to `!Settings > About Phone`! and tap `!Build Number`! 5 times to enable it.

-

`:Steps-to-Update
>>Steps to Update

`:1-Connect-to-Your-Device
>>>1. Connect to Your Device

Open the Meshtastic app and connect to the node you want to update via `!Bluetooth`! or `!USB`!.

`*[Image: Meshtastic iOS OTA upgrade screenshot]`*

`:2-Open-the-Firmware-Update-Screen
>>>2. Open the Firmware Update Screen

Navigate to `!Settings`! (gear icon) and look for the `!Firmware Update`! option. </ImageRight>

`:3-Select-and-Apply-the-Update
>>>3. Select and Apply the Update

The app will check for available firmware and guide you through the update process. Follow the on-screen prompts to download and flash the new firmware. `!Note that the Alpha updates are inherently unstable. Use at your own risk!`!

`:4-Wait-for-Completion
>>>4. Wait for Completion

The update will transfer over Bluetooth or USB. `!Do not disconnect or let your phone sleep`! during this process — the device will reboot automatically when finished.

-

`:Supported-Devices
>>Supported Devices

`t
| Device Type | Update Method | Supported Since |
| --- | --- | --- |
| nRF52 (e.g., RAK4631, T-Echo) | Bluetooth OTA | App v2.7.8 |
| ESP32 (e.g., T-Beam, Heltec) | Unified OTA | App v2.7.11 |
| USB DFU devices | USB OTG | App v2.7.9 |
`t

-

`:Troubleshooting
>>Troubleshooting

 • `!Update not appearing?`! Make sure your Meshtastic app is up to date from the iOS / Play Store.
 • `!Update interrupted?`! If your phone sleeps or disconnects mid-transfer, the device may need to be recovered via USB. See the official Meshtastic flashing guide (https://meshtastic.org/docs/getting-started/flashing-firmware/) for recovery steps.

<
-
Previous: `F79d`_`[Getting Started`:/page/meshtastic/getting-started.mu]`_`f
Next: `F79d`_`[Installation and configuration of the Mosquitto MQTT server`:/page/meshtastic/mqtt-server.mu]`_`f
On the web: https://michmesh.com/docs/Meshtastic/OTA_Meshtastic_Updates/
