#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f

`:Node-Builds
>Node Builds

Community build guides for mesh network nodes — solar builds, enclosures, and DIY setups. Whether you're putting together a budget solar node or designing a custom weatherproof enclosure, you'll find practical guides and parts lists here.

Have a build you'd like to share? Reach out on the MichMesh Discord (https://discord.gg/3A5RREcBcc)!

<
`!In this section`!

 • `F79d`_`[$30 HF Solar Node`:/page/node-builds/harbor-freight-solar-node.mu]`_`f
 • `F79d`_`[RAK4631 Solar Node`:/page/node-builds/rak4631-solar-node.mu]`_`f
 • `F79d`_`[Car Solar Node`:/page/node-builds/car-solar-node.mu]`_`f
 • `F79d`_`[Antenna Gain Testing`:/page/node-builds/antenna-gain-testing.mu]`_`f

<
-
Previous: `F79d`_`[Equipment!`:/page/gmrs/equipment.mu]`_`f
Next: `F79d`_`[$30 Harbor Freight Solar Node`:/page/node-builds/harbor-freight-solar-node.mu]`_`f
On the web: https://michmesh.com/docs/Node-Builds/
