#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Build Information`:/page/node-builds/index.mu]`_`f

`:RAK4631-Solar-Node
>RAK4631 Solar Node

A weatherproof solar node build using a RAK WisBlock starter kit and an IP67 junction box. The 3D-printed mounting board keeps the RAK board and 18650 batteries organized inside the enclosure. Works with both `!Meshtastic`! and `!MeshCore`! firmware.

STL files and additional details are available on the Thingiverse listing (https://www.thingiverse.com/thing:6849309).

`*[Image: RAK4631 solar node internals — RAK board and 18650 batteries on the 3D-printed mounting board]`*

`:Bill-of-Materials
>>Bill of Materials

`!RAK WisBlock Meshtastic Starter Kit (RAK19007 + RAK4631)`!
   Notes: ~$30 from RAK store or Amazon

`!IP67 junction box`!
   Notes: Weatherproof enclosure

`!18650 battery terminals`!
   Notes: AAA-to-18650 conversion contacts

`!N-connector pigtail (6")`!
   Notes: Coil excess inside the box, or use a shorter 3" pigtail

`!Breather plug`!
   Notes: Pressure equalization to prevent moisture buildup

`!USB-C 90° adapter`!
   Notes: Left on the board for firmware upgrades without disassembly

`!Antenna`!
   Notes: Choose based on your node location and deployment

`!Solar panel`!
   Notes: For charging the 18650 cells

`:Assembly-Notes
>>Assembly Notes

`:Mounting-Board
>>>Mounting Board

Print the 3D mounting board (`Fda5150x100_mounting_board.stl`f from Thingiverse). This holds the RAK WisBlock base board and 18650 battery terminals inside the junction box.

`*[Image: 3D-printed mounting board layout]`*

`:Enclosure
>>>Enclosure

The IP67-rated junction box keeps everything weatherproof. Drill holes for the N-connector and breather plug. The breather plug equalizes pressure so the enclosure doesn't trap moisture from temperature swings.

`:Antenna
>>>Antenna

The N-connector pigtail connects the RAK board's IPEX antenna port to an external antenna. The stock 6-inch pigtail can be coiled inside the box, but a 3-inch version is cleaner if you can find one. Choose your external antenna based on where you're deploying — an omnidirectional antenna works well for most setups.

`:Firmware-Access
>>>Firmware Access

The 90° USB-C adapter stays plugged into the RAK board so you can flash firmware updates without opening the enclosure — just pop open the box and plug in.

`*[Image: RAK node internals with wiring]`*

`*[Image: Deployed RAK solar node]`*

`:Firmware-Compatibility
>>Firmware Compatibility

This build works with both:

 • `!Meshtastic`! — the RAK starter kit comes pre-flashed with Meshtastic firmware. See the `F79d`_`[Meshtastic section`:/page/meshtastic/index.mu]`_`f for setup guides.
 • `!MeshCore`! — see the `F79d`_`[MeshCore section`:/page/meshcore/index.mu]`_`f for setup guides.

<
-
Previous: `F79d`_`[$30 Harbor Freight Solar Node`:/page/node-builds/harbor-freight-solar-node.mu]`_`f
Next: `F79d`_`[Car Solar Node`:/page/node-builds/car-solar-node.mu]`_`f
On the web: https://michmesh.com/docs/Node-Builds/RAK4631-Solar-Node/
