#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f

`:Affiliate-Groups
>Affiliate Groups

We are made up of multiple regional meshes, here are a few:

 • WestMichMesh (https://www.westmichmesh.org/)
 • Muskegon Mesh (https://muskegonmesh.org/)
 • KzooMesh (https://kzoomesh.org/)
 • EastSideMesh (https://eastsidemesh.com/)
 • ThumbMesh (https://thumbmesh.com/)
 • NorthernMichMesh (https://northernmichmesh.org/)
 • DetroitMesh (https://detroitmesh.com/) - Seems to be abandoned?

<
-
Previous: `F79d`_`[Contact Information`:/page/contact.mu]`_`f
On the web: https://michmesh.com/docs/affiliate-groups/
