#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f

`:GMRS
>GMRS

`:Its-Time-to-Get-Nerdy
>>It's Time to Get Nerdy...

Thats right... No off-grid or SHTF preparations are complete without voice communications, right? WELL. GMRS hits the spot. While you don't get the range you can with a HAM radio set-up, you also don't have the complications of a HAM setup. Even better, while the license is $35, its good for ten years, is shareable to your immediate family, AND requires no test! Even more so, some radios have built in GPS, compass, and the ability to share GPS information.

`:So-Whats-GMRS
>>So... What's GMRS?

From the fantastic overlords over at the FCC - General Mobile Radio Service (GMRS) (https://www.fcc.gov/wireless/bureau-divisions/mobility-division/general-mobile-radio-service-gmrs): The General Mobile Radio Service (GMRS) is a licensed radio service that uses channels around 462 MHz and 467 MHz. The most common use of GMRS channels is for short-distance, two-way voice communications using hand-held radios, mobile radios and repeater systems. In 2017, the FCC expanded GMRS to also allow short data messaging applications including text messaging and GPS location information.

Services that provide functionality similar to GMRS include the Citizens Band Radio Service (CBRS), the Family Radio Service (FRS) and the Multi-Use Radio Service (MURS).

The GMRS is available to an individual for short-distance two-way communications to facilitate the activities of licensees and their immediate family members. Each licensee manages a system consisting of one or more transmitting units (stations.) The rules for GMRS limit eligibility for new GMRS system licenses to individuals in order to make the service available to personal users. (Some previously licensed non-individual systems are allowed to continue using GMRS.)

In 2017, the FCC updated the GMRS by allotting additional interstitial channels in the 467 MHz band, increased the license term from 5 to 10 years, allowed transmission of limited data applications such as text messaging and GPS location information and made other updates to the GMRS rules to reflect modern application of the service.

`:Why-you-need-it
>>Why you need it...

Much like with LoRa devices like MeshTastic/Core, these radios are perfect for local "short range" communication, with similar limitations, line-of-sight being the biggest factor. Much like with your Mesh nodes, height is might, and the less "junk" in the way the better. Even in poor conditions with subpar antennas on your HT (hand held aka walkie-talkie) you can expect a few miles of range between you and another HT. Like with our favorite LoRa devices, there are ways to improve range and reception, and GMRS is no different. I won't get into the weeds here, that's for later. What's important is the "need" for it when it comes to off-grid coms. As mentioned above, what GMRS is NOT good for is LONG distance. You can't contact your HAM Uncle Jim in Tennessee or his 'Nam Vet buddy in Texas. What you CAN do is either connect to a local repeater to gain what ill call "regional" access depending on the repeater and its location, OR put up your own repeater and help serve your town, neighborhood, etc AND again, one license to serve all your devices. That also means you, your spouse, your 19 kids, your red-headed stepchildren, stepparents, grandparents, sisters, brothers, aunts, uncles, nieces, nephews, and in-laws can use the same license. The exception is non-related household members can ONLY use your equipment under your license in an emergency. Again, like our LoRa devices, there are plenty of portable and mobile options to bring your communication "network" with you on things like offroading, hiking, and camping trips, or build out your own "network" on your property. Lastly, the equipment can be simple charge-and-play to feature rich with lots of options including monitoring other frequencies like the aviation UNICOM channels. In summary my dear readers, it's an effective yet reasonably priced form of communication that is semi-expandable, doesn't require testing, and most importantly, doesn't require never ending ridicule from your Uncle Jim.

<
`!In this section`!

 • `F79d`_`[Getting Your License`:/page/gmrs/applyforlicense.mu]`_`f
 • `F79d`_`[Equipment`:/page/gmrs/equipment.mu]`_`f

<
-
Previous: `F79d`_`[Beta Script`:/page/reticulum/beta-script.mu]`_`f
Next: `F79d`_`[Getting your gmrs license`:/page/gmrs/applyforlicense.mu]`_`f
On the web: https://michmesh.com/docs/GMRS/
