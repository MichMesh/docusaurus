#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[GMRS`:/page/gmrs/index.mu]`_`f

`:Equipment
>Equipment!

This is going to be like going into a forum (yeah they still exist!) or Facebook group, and asking motorcycle guys which oil is the best oil to use. Ask the question, grab some popcorn, and watch the chaos you started. In the end, its going to come down to personal opinion, but we will do our best to break down some use cases and the options that we believe will go best. We are not responsible for any divorce that may commence after buying equipment.

-

`:HT-Hand-Held-aka-Walkie-Talkie
>>HT (Hand Held aka Walkie-Talkie)

`:As-Basic-as-Ugz-Cheap-and-Simple
>>>As Basic as Ugz (Cheap and Simple):

BF-888s - No frills, A knob for 16 channels, usually less than $10/radio in a 6 pack.

`:Less-Basic
>>>Less Basic

GM15    - A screen and buttons to switch channels/program the radio. USB charging

`:Feature-Rich
>>>Feature Rich

UV-GMRS - Waterproof, Bluetooth, GPS, Texting, NOAA, Location sharing UV-Pro  - Waterproof, UHF/VHF, Bluetooth, GPS, APRS, TNC, Texting, NOAA, Location sharing, GMRS, FRS, MURS, Ham.

`:Bonus-Content---Antennas
>>>Bonus Content - Antennas

-

`:Mobile-Pimp-your-Ride
>>Mobile (Pimp your Ride)

`:As-Basic-as-Ugz-Cheap-and-Simple-1
>>>As Basic as Ugz (Cheap and Simple):

Coming Soon

`:Less-Basic-1
>>>Less Basic

Coming Soon

`:Feature-Rich-1
>>>Feature Rich

Coming Soon

`:Antennas
>>>Antennas

Coming Soon

`:Antenna-Mounts
>>>Antenna Mounts

Coming Soon

-

`:Base-Station-Make-the-sad-HAMs-Jealous
>>Base Station (Make the sad HAMs Jealous)

`:As-Basic-as-Ugz-Cheap-and-Simple-2
>>>As Basic as Ugz (Cheap and Simple):

Coming Soon

`:Less-Basic-2
>>>Less Basic

Coming Soon

`:Feature-Rich-2
>>>Feature Rich

Coming Soon

`:Antennas-1
>>>Antennas

Coming Soon

-

Repeater

`:As-Basic-as-Ugz-Cheap-and-Simple-3
>>>As Basic as Ugz (Cheap and Simple):

Coming Soon

`:Less-Basic-3
>>>Less Basic

Coming Soon

`:Feature-Rich-3
>>>Feature Rich

Coming Soon

`:Antennas-2
>>>Antennas

Coming Soon

-

<
-
Previous: `F79d`_`[Getting your gmrs license`:/page/gmrs/applyforlicense.mu]`_`f
Next: `F79d`_`[Node Builds`:/page/node-builds/index.mu]`_`f
On the web: https://michmesh.com/docs/GMRS/Equipment/
