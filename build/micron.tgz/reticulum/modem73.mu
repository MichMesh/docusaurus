#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Reticulum`:/page/reticulum/index.mu]`_`f

`:This-is-still-in-beta-and-not-fully-rolled-out
>This is still in beta and not fully rolled out.

If you're interested in experimenting, feel free to build a node and help make the docs better!

`:How-to-setup-Modem73-on-Debian
>>How to setup Modem73 on Debian.

This assumes that you have already have a running RNS instance with config under `Fda5~/.reticulum/`f.

 1. Fetch and install the latest release of Modem73 for your platform from github (https://github.com/RFnexus/modem73/releases)
 2. Fetch and install the latest release of Modem73interface from github (https://github.com/RFnexus/modem73interface/) and save it under `Fda5~/.reticulum/interfaces/`f.
 3. Edit `Fda5~/.reticulum/config/`f and add the following lines to the `Fda5[interfaces]`f section.

`Fda5
`=
  [[MODEM73]]
    mode = internal
    type = Modem73Interface
    enabled = yes
    target_host = 127.0.0.1
    target_port = 8001
    control_host = 127.0.0.1
    control_port = 8073

`=
`f

 4. If you have `Fda5enable_transport = True`f set, check your other interface modes to sure they are setup in a way you wont flood the modem73 interface. If you just want to get it done, set your TCP interfaces to `Fda5mode = boundary`f and your internal interfaces to `Fda5mode = internal`f. If you want to experiment with other modes, give the announce simulator (https://rns.moscow/announce-sim.html) a try.
 5. Start modem73 in a terminal. The following is the minimal config.

 • Click on `Fda5CONFIG`f. `*[Image: Modem 73 config screen]`*
 • Change callsign to something to distinguish yourself while testing. Once you are running you can use N0CALL.
 • Pick your mode. For HF we are using either `Fda5ROBUST`f `Fda5RDM300`f or `Fda5RDM700`f. For UHF/VHF we are using `Fda5QAM4096`f `Fda52/3`f.
 • Enable CSMA, `Fda5MODE`f should be `Fda5SYNC`f. `Fda5PRESET`f should be `Fda5RELAXED`f.
 • RX Decoders - it will decode any mode that is not disabled. Setting the above only changes what it transmits. Disable the MFSK decoder - it will give a lot of false positives in your logs/`Fda5UTILS`f page.
 • Setup your audio interface and PTT. For me it is either the digirig `Fda5USB AUDIO DEVICE`f  or the `Fda5AIOC`f device for input and output.
 • PTT for DigiRig (https://digirig.net/) and AIOC (https://na6d.com/products/aioc-ham-radio-all-in-one-cable) use `Fda5PTT`f:`Fda5COM`f, select the device to use under `Fda5COM PORT`f, `Fda5PTT LINE`f is `Fda5RTS`f, `Fda5NORMAL`f or `Fda5NOT INVERTED`f. Stock `Fda5TX DELAY`f of 500ms has worked for my radios.
 • Click `Fda5QUIT`f to save, then restart. Setup another radio with the above or get a buddy to connect with on frequency - both of you should go to the `Fda5UTILS`f page of `Fda5Modem73`f and send some test messages, either `Fda51. Send Test Pattern`f, or `Fda58. Compose Message`f. If you're unsure of what modes will work for you, go to `Fda5TESTING`f and select the modes you want to test using `Fda5Auto-Alternate`f. It will cycle through the selected modes and show decodes on the other side under `Fda5[ RX PERFORMANCE ]`f. For RNS use, you will want any mode that is around 300 bps or faster. 500 bps or faster if you want to account for retransmissions caused by static crashes or other noise. Below that and you will have to go into the apps code and make timeout changes. `*[Image: Modem 73 Utils screen]`*
 • Once you are happy with your modem settings, you are now ready to flip the switch on RNS!

 6. Restart RNS to pick up the changes. If using our prev docs, use `Fda5sudo systemctl restart rnsd`f
 7. Send an announce! Does your other test radio or buddy on the other side see your announce? If so, Victory! If not, hit me (yNos) up on Signal or Discord so we can troubleshoot and fix these docs!

`:How-to-setup-Modem73-on-android-using-ThatSFguys-Reticulum-Mobile-app-via-Obtainium-step-1
>>How to setup Modem73 on android using ThatSFguy's Reticulum-Mobile-app via Obtainium (step 1)

With the little bit of testing I've done so far, the AIOC - All In One Cable (https://na6d.com/products/aioc-ham-radio-all-in-one-cable) and DigiRig (https://digirig.net/) are the only interfaces I've gotten to work.

 1. Install obtainium (https://obtainium.imranr.dev/).
 2. Open Obtainium
 3. Click `Fda5+ Add`f in the bottom right. `*Warning`*: the first time you install using Obtainium, it will ask you if you want to enable this software source. Click `Fda5Yes`f/`Fda5OK`f or toggle the switch that allows this source.
 4. To install the Reticulum app, paste `Fda5https://github.com/thatSFguy/reticulum-mobile-app/`f into the app source URL. Click `Fda5+`f next to the text entry box. on the next screen, click install. Click `Fda5INSTALL`f again if prompted.
 5. To install Modem73, paste `Fda5https://github.com/RFnexus/modem73-android`f into the app source URL. Click `Fda5+`f next to the text entry box. on the next screen, click install. Click `Fda5INSTALL`f again if prompted.
 6. Plug in your `Fda5AIOC`f before opening Modem73
 7. Open Modem73. Use Follow Debian Setup section 4. `*[Image: Modem 73 config screen]`*
 8. Open `Fda5Reticulum`f, go to `Fda5Settings`f, `Fda5Transports`f, and toggle `Fda5KISS TNC over TCP`f.  If you havent changed the network options in Modme73, you should be fine with all the defaults. `*[Image: Reticulum mobile transports config screen]`*
 9. Send an announce! Does your other test radio or buddy on the other side see your announce? If so, Victory! If not, hit me (yNos) up on Signal or Discord so we can troubleshoot and fix these docs!

`:What-radiosfrequencies-are-we-using-Modem73-on
>>What radios/frequencies are we using Modem73 on?

Currently there are a couple places we are experimenting, Part 90 commercial channels and part 15 ISM.

 • For Part 90, a MichMesh member is allowing the use of his unused itinerant frequencies. On UHF/High Band VHF, we are using a few DM1701s with an AIOC cable. There are plans to explore Low Band VHF as there are a few channels allocated down there, but we are still hunting for part 90 compliant gear.
 • Part 15 HF bands, 6.789 mHz USB and 13.556 mHz USB. 6.798 gives great daytime local coverage and longer distance coverage at night. 13.556 gives national and international coverage during the day and pretty much dries up at night.
 • Part 15 Caveats: Power! How much power can we run down here? There are a few different interpretations I've read online. Some say 1w , some say 3mw isotropic (free space, no ground losses, spherical cows, etc). From looking at FCC §15.225, we cant exceed 15,848 microvolts/meter at 30 meters. What does that mean? I wasnt sure, so I found my old wireless smart watch charger and tested what it put out. Here's an excerpt from my notes.

`Fda5
`=
Problem 1:
Knowing how much power we are allowed to output is a pain because they define it by energy 
density per meter square at 30m distance from the center of the radiator rather than watts ierp. 

Problem 2:
I dont have a calibrated field strength meter. 

Solution? Let's test a device that has passed FCC certification to see what it puts out, 
then make an oscillator with a variable output power amp that we can dial up  the output 
to match the known and take a measurement of that.

I may not have a calibrated FSM, but I do have a spectrum analyzer, a lora rubber duck
antenna, and pile of attenuators.

Let's hang the charger on a piece of clothes line at about 10 feet up, then take a 
measurement from 30m out. 

I then made an adjustable output power oscillator (si5351 and a few mosfets, 
adjusting bias voltage) and sent a cw tone through a qrp wattmeter, into a 
resonant half wave antenna at about 10 feet off the ground. The power needed 
to have a similar signal is about 250-300mw.
`=
`f

"But that's not what the equations say!" - This test was done in a field up against a forested area, near a river, with the water table being about 6 feet down and the soil being 4ish inches of black soil covering mostly river sand/gravel with a high iron ore content. Insert joke about spherical cows in a vaccum here.

`:Part-15-compatible-radios
>>>Part 15 compatible radios.

These will work on the frequency, but may need some modifications to meet power requirements.

 • My favorite is the LARCSet (https://www.hfsignals.com/index.php/larcset/). All surface mount parts are done for you, you just need to add in the bigger parts. When building, add 3 extra wraps to the VFO toroid and you should be good to go. Use another radio to verify you are on the correct frequency. You can also use a digital vfo (https://www.qrp-labs.com/digivfo.html) if you dont want to use the analog one. Tuning the power output is adjusted via a potentiometer on board. Set it to whatever power you need for your antenna. You can use a DigiRig (linked above) for the audio/PTT interface.
 • My second favorite is the "white button" style uSDX as it has ports on the back to use an AIOC. You can adjust the power output by dialing menu option 8.2 down till you meet the power reqs for your antenna/environment. No soldering required.
 • Same with the `Fda5[Tr]uSDX`f, only you cant use the AIOC w/o making a custom cable or adapter. Some have had luck with the Audio over CAT, but I'm not one of them.
 • I know of one person using a sBITx (https://www.hfsignals.com/index.php/sbitx/), but I cant really speak to what needs to be done to use it.
 • I'd love to see the PebbleHF (https://pebblehf.com/) on this list, hopefully we can order the 40m version soon. Let me know what radio you use, we can add it to the list.

<
-
Previous: `F79d`_`[How to setup an RNode from the CLI`:/page/reticulum/rnode.mu]`_`f
Next: `F79d`_`[Interfaces`:/page/reticulum/otherinterfaces.mu]`_`f
On the web: https://michmesh.com/docs/Reticulum/Modem73/
