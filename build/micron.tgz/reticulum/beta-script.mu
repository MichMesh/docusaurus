#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Reticulum`:/page/reticulum/index.mu]`_`f

`:Beta-Script
>Beta Script

Here is a test script (https://raw.githubusercontent.com/MichMesh/docusaurus/refs/heads/master/docs/files/setup_rns.sh) for installing and configuring RNS. It is still very beta.

`:How-to-use-it
>>How to use it.

 1. Download the file using wget and the link above `Fda5wget PASTEDLINK`f
 2. Make the file executable `Fda5chmod +x setup_rns.sh`f
 3. Run it with `Fda5./setup_rns.sh`f . It will ask the following questions:

 • Do you want to create a new python venv or use an existing. Unless you are really tight on space, create a new one - it will use around 350mb. We put it in a venv to isolate it from other python projects.
 • Which services to you want to install.
 • RNS is the base for everything else. If it is already installed, choose `Fda5n`f, otherwise `Fda5y`f.
 • LXMD is the propagation server - this is what stores messages for later pickup when you are not around. You probably don't want to enable this if you are on a public testnet `*and`* running off an SD card.
 • NomadNet is a text based interface as well as a web server equiv.
 • It will now ask if you want to setup Reticulum. If yes, it will start the service to generate the config and identity, then kill the service. You will see an error here and that's ok.
 • It will then ask if you want to enable transport mode. If enabled, this will act like a router or gateway between interfaces.
 • It will then ask if you want to enable an ipv4 backbone interface - this is what you would want if you are going to host an external server like rns.michmesh.net. If you do this, it will ask which interface you want to attach to.
 • It will then ask if you want to enable an ipv6 backbone. same as above.
 • It will then ask if you want to create the MichMesh interface. This is a connection to the regional test net.
 • It will then ask if you want to create your own tcp client to connect to another network. You will need to know the hostname or IP and port.
 • It will then ask if you want to configure LXMD - the propagation server from above.
 • It will then start the service to create the config and identity files. There will be a few errors here, they can usually be ignored.
 • It will then ask if you want to be a propagation node. If so, it will then ask what you want to name your node.
 • It will then ask if you want to enable RNS and LXMD systemctl.services. This will auto-start the services on boot.
 • It will then ask if you want to deploy an RNode. If so, plug in a compatible device and hit enter. After that you will need to manually setup your config using `F79d`_`[our rnode config page`:/page/reticulum/rnode.mu]`_`f or the reticulum interface page (https://reticulum.network/manual/interfaces.html#rnode-lora-interface) `*[Image: rns_setup.sh screenshot]`*

`:How-to-uninstall-after-using-the-script
>>How to uninstall after using the script.

 1. If you let is setup rns and lxmd services `Fda5sudo systemctl stop rnsd ; sudo systemctl stop lxmd; sudo systemctl disable rnsd; sudo systemctl disable lxmd`f
 2. Clean up the install and config dirs `Fda5rm -rf ~/reticulum ~/.reticulum; test -d ~/.lxmd && rm -rf ~/.lxmd`f

<
-
Previous: `F79d`_`[Services`:/page/reticulum/services.mu]`_`f
Next: `F79d`_`[GMRS`:/page/gmrs/index.mu]`_`f
On the web: https://michmesh.com/docs/Reticulum/beta_script/
