#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Reticulum`:/page/reticulum/index.mu]`_`f

`:Services
>Services

What good is a network without services? MichMesh runs two ways to talk with more than one person at a time:

`!Feels like`!
   `F79d`_`[Group Chat`#group-chat]`_`f: A group text
   `F79d`_`[Relay Chat (RRC)`#relay-chat-rrc]`_`f: IRC or Discord rooms

`!Client`!
   `F79d`_`[Group Chat`#group-chat]`_`f: Any LXMF messenger: Sideband, MeshChat, NomadNet, Reticulum Mobile App
   `F79d`_`[Relay Chat (RRC)`#relay-chat-rrc]`_`f: An RRC client: NomadNet, Reticulum Mobile App

`!Rooms`!
   `F79d`_`[Group Chat`#group-chat]`_`f: One chat per service
   `F79d`_`[Relay Chat (RRC)`#relay-chat-rrc]`_`f: Many rooms on one hub

`!Missed messages`!
   `F79d`_`[Group Chat`#group-chat]`_`f: Recent messages replayed when you join or rejoin
   `F79d`_`[Relay Chat (RRC)`#relay-chat-rrc]`_`f: Room history replayed when you join; `Fda5@mentions`f sent to your LXMF inbox while you're away

Both run over whatever connects you to the mesh: LoRa, TCP, or both. See `F79d`_`[Connect to the Reticulum Network`:/page/reticulum/getting-started.mu]`_`f to get a client online first.

`:group-chat
>>Group Chat

MichMesh's group chat runs reticulum-group-chat (https://github.com/thatSFguy/reticulum-group-chat) (`Fda5fwdsvc`f). It's an ordinary LXMF address that behaves like a chat room: anything a member sends to it is forwarded to every other member, tagged with the sender's nickname. There's nothing special to install. If you can send an LXMF message, you can use it.

`:join-group-chat
>>>Join the MichMesh Group Chat

 1. In your LXMF client, start a conversation with the MichMesh group chat: `F79d`_`[6e54f24ffb316ce6f5e5217e98664fa7`lxmf@6e54f24ffb316ce6f5e5217e98664fa7]`_`f
 2. Send `Fda5/join`f. You'll get a confirmation, followed by the most recent messages so you can catch up on the conversation.
 3. Send `Fda5/nick <name>`f to pick the name others see. Until you do, it uses your announced display name.
 4. Say hi. Everything you send from now on goes to the whole group.

A first message sent without `Fda5/join`f gets a reply explaining how to join; it isn't forwarded to anyone.

`:group-chat-commands
>>>Useful Commands

`!`Fda5/?`f or `Fda5/help`f`!
   What it does: Lists the commands available to you

`!`Fda5/info`f`!
   What it does: What this group is, and how to get in

`!`Fda5/users`f`!
   What it does: Who's in the group

`!`Fda5/nick <name>`f`!
   What it does: Change your nickname (letters, digits, `Fda5_`f and `Fda5-`f, up to 24)

`!`Fda5/pins`f`!
   What it does: The group's pinned messages

`!`Fda5/pause`f / `Fda5/resume`f`!
   What it does: Stop and restart receiving messages without leaving

`!`Fda5/textonly`f / `Fda5/showall`f`!
   What it does: Skip attachments, for slow or metered links, and turn them back on

`!`Fda5/leave`f`!
   What it does: Leave the group; `Fda5/join`f again any time

Members who haven't been heard from in a few weeks are removed automatically. Just `Fda5/join`f again.

`:relay-chat-rrc
>>Relay Chat (RRC)

Reticulum Relay Chat (https://rrc.kc1awv.net/) is IRC-style chat rooms over Reticulum. You connect to a `!hub`!, then join as many rooms as you like. MichMesh's hub runs reticulum-relay-chat (https://github.com/thatSFguy/reticulum-relay-chat), which adds two things a standard RRC hub doesn't do:

 • `!History and playback.`! The hub keeps a transcript of each room and replays recent messages when you join, so a room opens as a conversation already in progress, not a blank screen. Dropped off the mesh for a while? Reconnect and you're caught up. `Fda5/history`f asks for more.
 • `!Mentions while you're away.`! If someone writes `Fda5@yourname`f while you're disconnected, the hub sends it to your regular LXMF inbox (Sideband, MeshChat, etc.) as a direct message. It comes from an address named `Fda5<hub name>(noreply)`f, which only sends; reply in the room instead.

`:rrc-clients
>>>RRC Clients

 • `!NomadNet (https://github.com/markqvist/NomadNet)`! has a built-in RRC client, and opens `Fda5rrc://`f room links directly.
 • `!Reticulum Mobile App (https://github.com/thatSFguy/reticulum-mobile-app)`! (Android and iOS) has a `!Rooms`! tab. RRC is experimental and off by default: turn it on in Settings, then add the hub by its hash or tap it in the Nodes list, where RRC hubs are labelled.

`:join-rrc
>>>Join the MichMesh Hub

 1. In your RRC client, add the MichMesh hub: `Fda51303a636cf76ffffcf359761f0867e37`f
 2. Connect. You'll land in `Fda5#lobby`f, with its recent history.
 3. Send `Fda5/list`f to see the other rooms, and `Fda5/join <room>`f to enter one. You can also open a room link like `Fda5rrc://1303a636cf76ffffcf359761f0867e37/lobby`f.

Nicknames are first come, first served, and stay yours between visits. If someone already has the name you ask for, you'll get `Fda5name1`f and a notice saying so.

`!`Fda5Tip: Getting mentions in your inbox`f`!

Offline mentions go to the LXMF inbox of the `!same identity`! you used to connect to the hub. If your RRC client and your messaging app use different identities, mentions won't arrive. Send `Fda5/notify address`f in the hub and compare the address it shows with your messaging app's own. `Fda5/notify test`f sends a test notification.

`:rrc-commands
>>>Useful Commands

`!`Fda5/help`f`!
   What it does: Lists the commands you can run, or explains one

`!`Fda5/list`f`!
   What it does: Rooms on this hub

`!`Fda5/who [room]`f`!
   What it does: Who's in a room

`!`Fda5/history`f`!
   What it does: More of the room's history

`!`Fda5/link [room]`f`!
   What it does: A link to a room you can paste anywhere

`!`Fda5/mentions`f`!
   What it does: Mentions the hub is holding for you

`!`Fda5/seen <nick>`f`!
   What it does: When someone was last around

`!`Fda5/away`f / `Fda5/back`f`!
   What it does: Have mentions sent to your inbox even while you're connected, then turn that off

`!`Fda5/notify`f`!
   What it does: How the hub would reach you, and anything stopping it

`!`Fda5/whoami`f`!
   What it does: Who the hub thinks you are

`:Run-Your-Own
>>Run Your Own

Both services are single static binaries with no runtime to install. They run on anything from a Raspberry Pi Zero to a Linux server, and releases include Windows builds. Each project's README walks through setup; the short version is below.

Whichever you run, `!back up its identity file`!. The identity `*is`* the service's address: lose it and everyone has to find you at a new hash.

`:host-group-chat
>>>Group Chat

 1. Download `Fda5fwdsvc`f for your platform from the latest release (https://github.com/thatSFguy/reticulum-group-chat/releases/latest).
 2. Start from the example config (https://github.com/thatSFguy/reticulum-group-chat/blob/main/configs/fwdsvc.example.toml): set `Fda5display_name`f, and point `Fda5[[interfaces]]`f at a Reticulum node such as `Fda5rns.michmesh.net:7822`f or your own `Fda5rnsd`f.
 3. Run it once. The log prints the `!delivery destination`!, the address you share with your group.
 4. Message it from your LXMF client, copy your hash from its log into `Fda5admins`f, and restart.

The README covers running it under systemd (https://github.com/thatSFguy/reticulum-group-chat#linux--systemd-recommended), invite-only groups (https://github.com/thatSFguy/reticulum-group-chat#private-invite-only-groups), propagation-node delivery (https://github.com/thatSFguy/reticulum-group-chat#propagation) for offline members, and the full list of moderator commands.

`:host-rrc-hub
>>>RRC Hub

 1. Download `Fda5rrc-hub`f and `Fda5rrc-hub.example.toml`f from the `!same`! release (https://github.com/thatSFguy/reticulum-relay-chat/releases/latest); config keys change between versions.
 2. Set the hub `Fda5name`f, turn on `Fda5history_enabled`f if you want playback (it's off by default, because it stores conversations on disk), and add a `Fda5tcp_client`f interface pointing at a Reticulum node.
 3. Run `Fda5./rrc-hub -config rrc-hub.toml`f. The log prints the hash people add in their RRC client.

The README (https://github.com/thatSFguy/reticulum-relay-chat#deploy-it) has a systemd unit and the operating notes. In particular, keep the `Fda5ping_interval`f / `Fda5ping_timeout`f keepalive on: it's how the hub knows someone has left, and mention notifications depend on it.

`:Weather-Bot
>>Weather Bot

A bot that fetches the weather for your area, as well as grabbing live satellite images for your area.

 1. `Fda5mkdir -p ~/src/ ; git clone https://github.com/DayleDrinkwater/LXMF-WX-Bot.git ~/src/LXMF-WX-Bot`f
 2. Edit `Fda5wxbot.py`f, comment out/copy to a new line the `Fda5bot =`f definition and add your own name. for example:

`Fda5
`=
#bot = LXMFBot("Weather Bot - Send 'Help' for more info",announce=36000)
bot = LXMFBot("My Weather Bot - Send 'Help' for more info",announce=3600)
`=
`f

 3. Create `Fda5/etc/systemd/system/wxbot.service`f to more easily manage starting/stopping/auto-start the wxbot.

`Fda5
`=
[Unit]
Description=LXMF WXbot
After=multi-user.target

[Service]
Type=simple
Restart=always
RestartSec=3
User=YOURUSERNAME
ExecStart=/home/YOURUSERNAME/reticulum/bin/python3 /home/YOURUSERNAME/src/LXMF-WX-Bot/wxbot.py

[Install]
WantedBy=multi-user.target
`=
`f

 4. Start the service to make sure it's working. `Fda5sudo systemctl start wxbot.service`f

 • If there is an error in the service file, you will need to let systemd know when you've updated the .service file. You do this by running `Fda5sudo systemctl daemon-reload`f

 5. If the service is running, you can enable automatic startup by running `Fda5sudo systemctl enable wxbot`f

<
-
Previous: `F79d`_`[Interfaces`:/page/reticulum/otherinterfaces.mu]`_`f
Next: `F79d`_`[Beta Script`:/page/reticulum/beta-script.mu]`_`f
On the web: https://michmesh.com/docs/Reticulum/Services/
