#!c=86400
`F79d`_`[MichMesh`:/page/index.mu]`_`f / `F79d`_`[Reticulum`:/page/reticulum/index.mu]`_`f

`:Connect-to-the-Reticulum-Network
>Connect to the Reticulum Network

`:Clients
>>Clients

No radio needed to get started: each of these can join the network over the internet through a public TCP hub. The public hubs are generally linked together, so any of them should put you on the wider network; MichMesh runs one at `Fda5RNS.MichMesh.net`f, port `Fda57822`f. Once you're on, say hi in the `F79d`_`[group chat`:/page/reticulum/services.mu`anchor=join-group-chat]`_`f.

`:web-client
>>>Web Client (Fastest Way to Try It)

The Reticulum web client (https://github.com/thatSFguy/reticulum-webclient) runs in your browser, so there's nothing to install except a small bridge program. Browsers can't open TCP connections themselves; the bridge passes traffic between the page and a Reticulum hub.

 1. On a computer, open the web client (https://thatsfguy.github.io/reticulum-webclient/) in any browser. On a phone, use the `F79d`_`[mobile app`#mobile-app]`_`f instead.
 2. Click `!Connect via TCP → Download the bridge`!. It's available for Windows, Linux, and macOS on Apple Silicon.
 3. Run the bridge and leave it running. On Linux and macOS, `Fda5chmod +x`f it first. Windows may warn that the file is unrecognized, since it isn't code-signed.
 4. Back in the browser, click `!Connect (WebSocket)`!. The hub field comes filled in with a public hub, so you can connect as-is. If it won't connect, or you'd rather use MichMesh's, enter `Fda5RNS.MichMesh.net`f port `Fda57822`f.
 5. Set your `!display name`! and click `!Send Announce`! so others can reach you. Other nodes show up in your contacts as their announces arrive.
 6. Click `!Export Identity`! to back up your keys. Your identity lives in this browser, so clearing its site data deletes it.

Have an `F79d`_`[RNode`:/page/reticulum/rnode.mu]`_`f? In Chrome, Edge or Brave the web client can also talk to it directly over Bluetooth or USB, with no bridge and no internet. The web client's TCP bridge guide (https://github.com/thatSFguy/reticulum-webclient/blob/main/docs/TCP-BRIDGE.md) covers running the bridge against your own `Fda5rnsd`f.

`:mobile-app
>>>Reticulum Mobile App (Android/iOS)

The Reticulum Mobile App (https://github.com/thatSFguy/reticulum-mobile-app) is a native messaging client for Android and iOS. It connects over TCP, or to an RNode over Bluetooth or USB, and also browses NomadNet pages.

 1. Install it:

    • `!Android:`! the APK from the latest release (https://github.com/thatSFguy/reticulum-mobile-app/releases/latest), or through Obtainium (https://obtainium.imranr.dev/) for automatic updates.
    • `!iOS:`! through AltStore or SideStore; see the iOS install steps (https://github.com/thatSFguy/reticulum-mobile-app#install-on-ios-via-altstore--sidestore).
 2. Go to `!Settings → Connection`! and, under `!TCP`!, tap `!Connect TCP`!. `!Host`! and `!Port`! come filled in with a public hub the app picked, so you can connect as-is. If it won't connect, or you'd rather use MichMesh's, set `!Host`! to `Fda5RNS.MichMesh.net`f and `!Port`! to `Fda57822`f.
 3. On Android, tap `!Disable battery optimization`! in the same section. Otherwise the phone may stop the app in the background and you'll miss messages.
 4. Set your `!Display name`! and tap `!Send announce`!.

People and services appear in the `!Nodes`! tab as their announces arrive, and conversations live in `!Messages`!.

`:meshchat
>>>MeshChat (Windows/macOS/Linux)

MeshChat (https://github.com/liamcottle/reticulum-meshchat) is a desktop app with a web-style interface for messaging and browsing NomadNet. Install it from the releases page (https://github.com/liamcottle/reticulum-meshchat/releases), then connect it to a hub:

 1. Click `!Interfaces`! on the left, then `!Add Interface`!.
 2. Fill in:

    • `!Name:`! MichMesh
    • `!Type:`! TCP Client Interface
    • `!Target Host:`! `Fda5RNS.MichMesh.net`f, or any other public hub
    • `!Target Port:`! `Fda57822`f
 3. Click `!Add Interface`!, then restart the app.

Once it restarts, announces show up under `!Messages`! and `!Nomad Network`!. Click one to send a message or browse a node.

Optional: under `!Settings`!, `!Enable Transport Mode`! lets other Reticulum devices on your home network reach the mesh through this computer.

`:sideband
>>>Sideband (Android/Linux/macOS/Windows)

Sideband (https://github.com/markqvist/Sideband) is an LXMF messaging app with maps and telemetry sharing. Skip this if you're on the same home network as a Reticulum node that has transport enabled; Sideband finds it on its own.

`!On Android:`!

 1. Open the menu and tap `!Connectivity`!.
 2. Turn on `!Connect via TCP`!.
 3. Set `!TCP Host`! to `Fda5RNS.MichMesh.net`f (or any other public hub) and `!TCP Port`! to `Fda57822`f.
 4. Close the screen and restart Sideband.

`!On a computer:`! Sideband uses a Reticulum config file instead. Its `!Connectivity`! screen shows where the file is. Add the `Fda5[[MichMesh TCP]]`f interface from the `F79d`_`[sample config`#sample-config]`_`f below to it, then restart Sideband.

Announces from other nodes should start appearing in the announce stream.

`:nomadnet
>>>NomadNet (Terminal)

NomadNet (https://github.com/markqvist/NomadNet) is a text-based client for messaging, browsing and hosting pages, and it has an RRC client for `F79d`_`[Relay Chat`:/page/reticulum/services.mu`anchor=relay-chat-rrc]`_`f. Install it into the same Python environment as Reticulum (see `F79d`_`[Install Reticulum`#install]`_`f below):

`Fda5
`=
pip install nomadnet
nomadnet
`=
`f

NomadNet connects through your Reticulum config: if `Fda5rnsd`f is running, it uses that; otherwise it reads `Fda5~/.reticulum/config`f. Either way, add the `F79d`_`[sample config`#sample-config]`_`f's TCP interface to reach the mesh.

`:host-your-own-node
>>Host Your Own Node

Running `Fda5rnsd`f on an always-on machine, like a Raspberry Pi or home server, gives every Reticulum app on that machine one shared connection. With transport enabled, it also connects the other devices on your home network.

`:install
>>>Install Reticulum

 1. Create a Python virtual environment for Reticulum, and activate it. On Debian and Raspberry Pi OS you may need `Fda5sudo apt install python3-venv`f first.

`Fda5
`=
   python3 -m venv ~/reticulum
   . ~/reticulum/bin/activate
`=
`f
 2. Install Reticulum (`Fda5rns`f) and LXMF (`Fda5lxmf`f, which provides the `Fda5lxmd`f daemon):

`Fda5
`=
   pip install --upgrade rns lxmf
`=
`f
 3. Run `Fda5rnsd`f once to generate the default config files, then stop it with Ctrl-C.

`:systemd
>>>Start on Boot

Create `Fda5/etc/systemd/system/rnsd.service`f with `Fda5sudo`f and your favorite text editor. Use this as a template, replacing `Fda5YOURUSERNAME`f with the user you installed Reticulum as:

`Fda5
`=
[Unit]
Description=Reticulum Network Service Daemon
After=multi-user.target

[Service]
Type=simple
Restart=always
RestartSec=3
User=YOURUSERNAME
ExecStart=/home/YOURUSERNAME/reticulum/bin/rnsd

[Install]
WantedBy=multi-user.target
`=
`f

Run `Fda5sudo systemctl start rnsd`f. If that works, `Fda5sudo systemctl enable rnsd`f starts it on every boot.

`:sample-config
>>>Sample Interface Configuration

Reticulum needs something to connect to. This config, in `Fda5~/.reticulum/config`f, connects your node to two things:

 • `!Default Interface`! finds other Reticulum devices on your local network automatically.
 • `!MichMesh TCP`! connects to MichMesh's hub, and through it the wider mesh.

With `Fda5enable_transport`f on, your node also relays between them, so devices on your home network can reach the mesh through it.

`Fda5
`=
[reticulum]
  enable_transport = True
  share_instance = Yes
  shared_instance_port = 37428
  instance_control_port = 37429
  panic_on_interface_error = No

[logging]
  loglevel = 4

[interfaces]
  [[Default Interface]]
    type = AutoInterface
    enabled = Yes

  [[MichMesh TCP]]
    type = TCPClientInterface
    enabled = Yes
    target_host = rns.michmesh.net
    target_port = 7822
`=
`f

Any public hub works in place of MichMesh's. Restart `Fda5rnsd`f after any change to the config: `Fda5sudo systemctl restart rnsd`f. To add radios, see `F79d`_`[RNode`:/page/reticulum/rnode.mu]`_`f and `F79d`_`[Other Interfaces`:/page/reticulum/otherinterfaces.mu]`_`f.

`:vocabulary
>>Vocabulary

`!`!Node`!`!
   Meaning: A participant in the Reticulum network

`!`!RNS`!`!
   Meaning: Short for Reticulum Network Stack

`!`!LXMF`!`!
   Meaning: The messaging protocol built on Reticulum that most chat apps use

`!`!Announce`!`!
   Meaning: A broadcast that tells the network how to reach you

`!`!Transport Mode`!`!
   Meaning: Lets a node route and forward other nodes' traffic

`!`!Propagation Node`!`!
   Meaning: A node that holds encrypted messages for people who are offline, and delivers them when they reconnect

<
-
Previous: `F79d`_`[Intro To Reticulum`:/page/reticulum/index.mu]`_`f
Next: `F79d`_`[How to setup an RNode from the CLI`:/page/reticulum/rnode.mu]`_`f
On the web: https://michmesh.com/docs/Reticulum/Getting_Started/
